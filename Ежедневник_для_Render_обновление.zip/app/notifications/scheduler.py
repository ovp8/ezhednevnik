# notifications/scheduler.py
"""Планировщик напоминаний.

Раз в N секунд проверяет БД и вызывает backend.show() для наступивших.
Если сработавшее напоминание помечено repeat_interval_min > 0,
и задача ещё не выполнена, и лимит повторов не исчерпан —
создаёт дочернюю запись kind='repeat' на now + interval.
"""
import asyncio
from datetime import datetime, timezone
from typing import Optional, Callable
from notifications.storage import ReminderStorage
from notifications.backends import BaseBackend


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


class ReminderScheduler:
    def __init__(self, storage: ReminderStorage, backend: BaseBackend,
                 tick_interval: int = 30,
                 on_fired: Optional[Callable] = None,
                 task_status_getter: Optional[Callable] = None):
        """
        :param storage: ReminderStorage
        :param backend: BaseBackend
        :param tick_interval: как часто проверять БД (сек)
        :param on_fired: callback(reminder_dict) — вызывается после показа
        :param task_status_getter: Callable(task_id) -> int (0=не выполнено, 1=выполнено)
                                    Нужен для автоповтора. Если None — повторы не работают.
        """
        self.storage = storage
        self.backend = backend
        self.tick_interval = tick_interval
        self.on_fired = on_fired
        self.task_status_getter = task_status_getter
        self._task: Optional[asyncio.Task] = None
        self._stop = False

    def start(self):
        if self._task and not self._task.done():
            return
        self._stop = False
        self._task = asyncio.create_task(self._run())
        print(f"[reminder] scheduler started, interval={self.tick_interval}s")

    async def stop(self):
        self._stop = True
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except Exception:
                pass
        self._task = None
        print("[reminder] scheduler stopped")

    def request_stop(self):
        """Синхронная остановка «по флагу» — безопасна без живого event loop."""
        self._stop = True

    async def check_now(self):
        # Обработка «Не напоминать»: если Kotlin-сторона пометила задачу —
        # удаляем её reminders из SQLite и чистим флаг.
        self._process_cancel_requests()

        now = _now_iso()
        due = self.storage.get_due(now)
        if not due:
            return
        print(f"[reminder] due reminders: {len(due)}")
        for r in due:
            await self._fire_one(r)

    def _process_cancel_requests(self):
        # Android-SharedPreferences существуют только на телефоне;
        # на веб-сервере ветка бессмысленна — молча пропускаем.
        try:
            from platform_caps import android_available
            if not android_available():
                return
        except Exception:
            pass
        """Читает из SharedPreferences флаг cancel_request_task_id и сносит
        напоминания этой задачи из SQLite."""
        try:
            from jnius import autoclass
            ActivityThread = autoclass("android.app.ActivityThread")
            app = ActivityThread.currentApplication()
            if app is None:
                return
            ctx = app.getApplicationContext()
            Context = autoclass("android.content.Context")
            prefs = ctx.getSharedPreferences("ordnungen_alarms", Context.MODE_PRIVATE)
            tid = int(prefs.getInt("cancel_request_task_id", 0))
            if tid <= 0:
                return
            # Сносим все reminders задачи
            self.storage.delete_for_task(tid)
            print(f"[reminder] cancel_request processed: task_id={tid}")
            # Чистим флаг
            editor = prefs.edit()
            editor.putInt("cancel_request_task_id", 0)
            editor.apply()
        except Exception as ex:
            print(f"[reminder] cancel_request error: {ex}")

    async def _fire_one(self, r: dict):
        kind = r.get("kind") or "before"
        minutes = int(r.get("minutes_before", 0) or 0)

        # Заголовок уведомления зависит от роли
        if kind == "before" and minutes > 0:
            title = f"Через {minutes} мин"
        elif kind == "at_time":
            title = "Пора начинать"
        elif kind == "repeat":
            title = "Задача не выполнена"
        else:
            title = "Напоминание"

        body = r.get("task_text", "")

        try:
            await self.backend.show(title, body, extra=dict(r))
        except Exception as ex:
            print(f"[reminder] show error: {ex}")

        # Помечаем сработавшим
        self.storage.mark_fired(r["id"])

        # Автоповтор
        try:
            self._maybe_create_repeat(r)
        except Exception as ex:
            print(f"[reminder] repeat error: {ex}")

        if self.on_fired:
            try:
                result = self.on_fired(r)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as ex:
                print(f"[reminder] on_fired error: {ex}")

    def _maybe_create_repeat(self, r: dict):
        interval = int(r.get("repeat_interval_min") or 0)
        if interval <= 0:
            return
        repeat_max = int(r.get("repeat_max") or 0)
        repeat_count = int(r.get("repeat_count") or 0)
        if repeat_count >= repeat_max:
            print(f"[reminder] repeat limit reached ({repeat_count}/{repeat_max})")
            return

        task_id = int(r.get("task_id") or 0)
        if task_id <= 0:
            return

        # Проверяем, что задача ещё не выполнена
        if self.task_status_getter is not None:
            status = self.task_status_getter(task_id)
            if status == 1:
                print(f"[reminder] task {task_id} is done, no repeat")
                return

        # НЕ дублировать: если уже есть активный (fired=0) repeat —
        # не создавать ещё один. Иначе before и at_time создадут два повтора.
        try:
            existing = self.storage.get_for_task(task_id)
            for e in existing:
                if e.get("kind") == "repeat" and not e.get("fired"):
                    print(f"[reminder] repeat already pending for task {task_id}, skip")
                    return
        except Exception as ex:
            print(f"[reminder] check pending repeat error: {ex}")

        new_count = repeat_count + 1
        self.storage.add_repeat(
            task_id=task_id,
            task_text=r.get("task_text", ""),
            interval_min=interval,
            repeat_max=repeat_max,
            repeat_count=new_count,
        )
        print(f"[reminder] scheduled repeat {new_count}/{repeat_max} "
              f"for task_id={task_id} in {interval} min")

    async def _run(self):
        await asyncio.sleep(2)
        while not self._stop:
            try:
                await self.check_now()
            except Exception as ex:
                print(f"[reminder] loop error: {ex}")
            await asyncio.sleep(self.tick_interval)