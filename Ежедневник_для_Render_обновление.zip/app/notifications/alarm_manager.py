"""
Постановка нативных Android-будильников через pyjnius.
Fallback: если SCHEDULE_EXACT_ALARM не выдан — используем неточный set().
Все логи — через print (logger.info не виден в logcat по умолчанию).
"""
import json
from datetime import datetime, timezone

_ALARMS_PREF_NAME = "ordnungen_alarms"
_ALARMS_KEY = "alarms"
_RECEIVER_CLASS = "com.flet.dailyplanner.ReminderReceiver"
_ACTION_SHOW = "com.flet.dailyplanner.SHOW_REMINDER"


def _log(msg: str):
    print(f"[alarm] {msg}", flush=True)


# ---------------- Context / Activity ----------------

def _get_android_context():
    try:
        from platform_caps import android_available
        if not android_available():
            return None
    except Exception:
        pass
    try:
        from jnius import autoclass
        ActivityThread = autoclass("android.app.ActivityThread")
        app = ActivityThread.currentApplication()
        if app is None:
            return None
        return app.getApplicationContext()
    except Exception as e:
        _log(f"context unavailable: {e}")
        return None


def _get_current_activity():
    try:
        from platform_caps import android_available
        if not android_available():
            return None
    except Exception:
        pass
    try:
        from jnius import autoclass
        ActivityThread = autoclass("android.app.ActivityThread")
        thread = ActivityThread.currentActivityThread()
        if thread is None:
            return None
        mActivities = thread.mActivities
        if mActivities is None or mActivities.size() == 0:
            return None
        for i in range(mActivities.size()):
            record = mActivities.valueAt(i)
            if record is None:
                continue
            activity = record.activity
            if activity is not None:
                return activity
        return None
    except Exception as e:
        _log(f"activity unavailable: {e}")
        return None


# ---------------- Helpers: Intent через Bundle с явными String ----------------

def _make_receiver_intent(context, task_id: int, title: str, body: str,
                          notification_id: int = None):
    """Все extras передаём как String через Bundle — обход jnius overload-проблемы."""
    from jnius import autoclass
    Intent = autoclass("android.content.Intent")
    Bundle = autoclass("android.os.Bundle")
    JavaString = autoclass("java.lang.String")

    nid = int(notification_id) if notification_id is not None else int(task_id)

    bundle = Bundle()
    bundle.putString(JavaString("title"), JavaString(str(title)))
    bundle.putString(JavaString("body"), JavaString(str(body)))
    bundle.putString(JavaString("notificationId"), JavaString(str(nid)))
    bundle.putString(JavaString("task_id"), JavaString(str(task_id)))

    intent = Intent()
    intent.setClassName(
        JavaString(str(context.getPackageName())),
        JavaString(_RECEIVER_CLASS),
    )
    intent.setAction(JavaString(_ACTION_SHOW))
    intent.putExtras(bundle)
    return intent


# ---------------- SharedPreferences ----------------

def _read_alarms_prefs(context) -> list:
    try:
        from jnius import autoclass
        Context = autoclass("android.content.Context")
        prefs = context.getSharedPreferences(_ALARMS_PREF_NAME, Context.MODE_PRIVATE)
        raw = prefs.getString(_ALARMS_KEY, "[]")
        return json.loads(raw) if raw else []
    except Exception as e:
        _log(f"read prefs failed: {e}")
        return []


def _write_alarms_prefs(context, alarms: list):
    try:
        from jnius import autoclass
        Context = autoclass("android.content.Context")
        prefs = context.getSharedPreferences(_ALARMS_PREF_NAME, Context.MODE_PRIVATE)
        editor = prefs.edit()
        editor.putString(_ALARMS_KEY, json.dumps(alarms, ensure_ascii=False))
        editor.apply()
        _log(f"saved {len(alarms)} alarms to prefs")
    except Exception as e:
        _log(f"write prefs failed: {e}")


# ---------------- Разрешения ----------------

def has_exact_alarm_permission() -> bool:
    context = _get_android_context()
    if context is None:
        return False
    try:
        from jnius import autoclass, cast
        Build = autoclass("android.os.Build$VERSION")
        if Build.SDK_INT < 31:
            _log("exact alarm permission: not needed (SDK < 31)")
            return True
        Context = autoclass("android.content.Context")
        AlarmManager = autoclass("android.app.AlarmManager")
        am = cast(AlarmManager, context.getSystemService(Context.ALARM_SERVICE))
        granted = bool(am.canScheduleExactAlarms())
        _log(f"exact alarm permission granted={granted}")
        return granted
    except Exception as e:
        _log(f"exact alarm check failed: {e}")
        return False


def request_exact_alarm_permission() -> bool:
    activity = _get_current_activity()
    context = _get_android_context()
    if activity is None or context is None:
        _log("no activity, cannot request exact alarm permission")
        return False
    try:
        from jnius import autoclass
        Settings = autoclass("android.provider.Settings")
        Intent = autoclass("android.content.Intent")
        Uri = autoclass("android.net.Uri")
        intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        intent.setData(Uri.parse("package:" + context.getPackageName()))
        activity.startActivity(intent)
        _log("opened exact alarm settings")
        return True
    except Exception as e:
        _log(f"request exact alarm failed: {e}")
        return False


def is_ignoring_battery_optimizations() -> bool:
    context = _get_android_context()
    if context is None:
        return False
    try:
        from jnius import autoclass, cast
        Context = autoclass("android.content.Context")
        PowerManager = autoclass("android.os.PowerManager")
        pm = cast(PowerManager, context.getSystemService(Context.POWER_SERVICE))
        result = bool(pm.isIgnoringBatteryOptimizations(context.getPackageName()))
        _log(f"ignoring battery optimizations={result}")
        return result
    except Exception as e:
        _log(f"battery whitelist check failed: {e}")
        return False


def request_ignore_battery_optimizations() -> bool:
    activity = _get_current_activity()
    context = _get_android_context()
    if activity is None or context is None:
        _log("no activity, cannot request battery whitelist")
        return False
    try:
        from jnius import autoclass, cast
        Settings = autoclass("android.provider.Settings")
        Intent = autoclass("android.content.Intent")
        Uri = autoclass("android.net.Uri")
        PowerManager = autoclass("android.os.PowerManager")
        pm = cast(PowerManager, context.getSystemService(
            autoclass("android.content.Context").POWER_SERVICE))
        if pm.isIgnoringBatteryOptimizations(context.getPackageName()):
            _log("already whitelisted, no action needed")
            return True
        intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        intent.setData(Uri.parse("package:" + context.getPackageName()))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
        _log("opened battery optimization settings")
        return True
    except Exception as e:
        _log(f"request battery whitelist failed: {e}")
        return False


# ---------------- Будильники ----------------

def _set_alarm_safely(alarm_manager, fire_at_ms: int, pending, tag: str) -> bool:
    """
    Ставит будильник с fallback:
      - если есть разрешение на exact → setExactAndAllowWhileIdle
      - иначе → set (неточный, но не падает)
    """
    from jnius import autoclass
    AlarmManager = autoclass("android.app.AlarmManager")
    RTC_WAKEUP = AlarmManager.RTC_WAKEUP

    if has_exact_alarm_permission():
        try:
            alarm_manager.setExactAndAllowWhileIdle(RTC_WAKEUP, fire_at_ms, pending)
            _log(f"{tag} set EXACT at ms={fire_at_ms}")
            return True
        except Exception as e:
            _log(f"{tag} exact set failed: {e} — fallback to inexact")

    try:
        alarm_manager.set(RTC_WAKEUP, fire_at_ms, pending)
        _log(f"{tag} set INEXACT at ms={fire_at_ms} (exact perm denied)")
        return True
    except Exception as e:
        _log(f"{tag} INEXACT set failed too: {e}")
        return False


def schedule_alarm(task_id: int, fire_at_utc: datetime, title: str, body: str = "",
                   notification_id: int = None) -> bool:
    context = _get_android_context()
    if context is None:
        _log("no android context, skip native alarm")
        return False

    fire_at_ms = int(fire_at_utc.timestamp() * 1000)
    now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)

    if fire_at_ms <= now_ms:
        _log(f"fire_at in the past, skip: {fire_at_utc.isoformat()}")
        return False

    try:
        from jnius import autoclass, cast

        intent = _make_receiver_intent(
            context, task_id, title, body,
            notification_id=notification_id,   # ← НОВОЕ
        )

        PendingIntent = autoclass("android.app.PendingIntent")
        FLAG_UPDATE_CURRENT = PendingIntent.FLAG_UPDATE_CURRENT
        FLAG_IMMUTABLE = 1 << 26
        pending = PendingIntent.getBroadcast(
            context, int(task_id), intent,
            FLAG_UPDATE_CURRENT | FLAG_IMMUTABLE,
        )

        Context = autoclass("android.content.Context")
        AlarmManager = autoclass("android.app.AlarmManager")
        alarm_manager = cast(
            AlarmManager,
            context.getSystemService(Context.ALARM_SERVICE),
        )

        ok = _set_alarm_safely(alarm_manager, fire_at_ms, pending, f"task_id={task_id}")
        if not ok:
            return False

    except Exception as e:
        _log(f"failed to schedule native alarm: {e}")
        import traceback
        print(traceback.format_exc(), flush=True)
        return False

    # Сохраняем в prefs для BootReceiver
    nid = int(notification_id) if notification_id is not None else int(task_id)
    alarms = _read_alarms_prefs(context)
    alarms = [a for a in alarms if a.get("task_id") != task_id]
    alarms.append({
        "task_id": task_id,
        "fire_at_ms": fire_at_ms,
        "title": title,
        "body": body,
        "notification_id": nid,   # ← НОВОЕ
    })
    _write_alarms_prefs(context, alarms)
    return True


def cancel_alarm(task_id: int) -> bool:
    context = _get_android_context()
    if context is None:
        return False
    try:
        from jnius import autoclass, cast

        intent = _make_receiver_intent(context, task_id, "", "")

        PendingIntent = autoclass("android.app.PendingIntent")
        FLAG_NO_CREATE = PendingIntent.FLAG_NO_CREATE
        FLAG_IMMUTABLE = 1 << 26
        pending = PendingIntent.getBroadcast(
            context, int(task_id), intent, FLAG_NO_CREATE | FLAG_IMMUTABLE,
        )
        if pending is not None:
            Context = autoclass("android.content.Context")
            AlarmManager = autoclass("android.app.AlarmManager")
            am = cast(AlarmManager, context.getSystemService(Context.ALARM_SERVICE))
            am.cancel(pending)

        # Дополнительно: скрываем уже показанное уведомление из шторки
        try:
            Context = autoclass("android.content.Context")
            NotificationManager = autoclass("android.app.NotificationManager")
            nm = cast(
                NotificationManager,
                context.getSystemService(Context.NOTIFICATION_SERVICE),
            )
            nm.cancel(int(task_id))
            # Также отменяем возможное "at_time" уведомление
            nm.cancel(int(task_id) + 1000000)
            _log(f"notification cancelled for task_id={task_id}")
        except Exception as ne:
            _log(f"notification cancel failed: {ne}")

        _log(f"cancelled task_id={task_id}")
    except Exception as e:
        _log(f"cancel failed: {e}")

    alarms = _read_alarms_prefs(context)
    alarms = [a for a in alarms if a.get("task_id") != task_id]
    _write_alarms_prefs(context, alarms)
    return True


def get_pending_alarms() -> list:
    context = _get_android_context()
    if context is None:
        return []
    return _read_alarms_prefs(context)


def clear_all_alarms() -> bool:
    context = _get_android_context()
    if context is None:
        return False
    try:
        from jnius import autoclass, cast
        Context = autoclass("android.content.Context")
        AlarmManager = autoclass("android.app.AlarmManager")
        PendingIntent = autoclass("android.app.PendingIntent")
        FLAG_NO_CREATE = PendingIntent.FLAG_NO_CREATE
        FLAG_IMMUTABLE = 1 << 26

        am = cast(AlarmManager, context.getSystemService(Context.ALARM_SERVICE))
        for a in _read_alarms_prefs(context):
            tid = int(a.get("task_id", 0))
            intent = _make_receiver_intent(context, tid, "", "")
            pending = PendingIntent.getBroadcast(
                context, tid, intent, FLAG_NO_CREATE | FLAG_IMMUTABLE,
            )
            if pending is not None:
                am.cancel(pending)
        _write_alarms_prefs(context, [])
        _log("all alarms cleared")
        return True
    except Exception as e:
        _log(f"clear_all failed: {e}")
        return False

def clear_legacy_channels():
    """Удаляет старые каналы, созданные предыдущими версиями backends.py."""
    context = _get_android_context()
    if context is None:
        return False
    try:
        from jnius import autoclass, cast
        Context = autoclass("android.content.Context")
        NotificationManager = autoclass("android.app.NotificationManager")
        Build = autoclass("android.os.Build$VERSION")
        if Build.SDK_INT < 26:
            return True
        nm = cast(NotificationManager, context.getSystemService(Context.NOTIFICATION_SERVICE))
        for ch_id in ("reminders", "reminders_v2", "reminders_v3"):
            try:
                nm.deleteNotificationChannel(ch_id)
                _log(f"deleted legacy channel: {ch_id}")
            except Exception as ex:
                _log(f"delete channel {ch_id} error: {ex}")
        return True
    except Exception as e:
        _log(f"clear legacy channels failed: {e}")
        return False