package {{ cookiecutter.org_name_2 }}.{{ cookiecutter.package_name }}

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

class SnoozeReceiver : BroadcastReceiver() {
    private val TAG = "SnoozeReceiver"
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getIntExtra("task_id", 0)
        val minutes = intent.getIntExtra("minutes", 5)
        val title = intent.getStringExtra("title") ?: "Напоминание"
        val body = intent.getStringExtra("body") ?: ""
        Log.i(TAG, "onReceive task_id=$taskId minutes=$minutes")
        if (taskId <= 0) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(taskId)
        val fireAtMs = System.currentTimeMillis() + minutes * 60_000L
        val alarmIntent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", title)
            putExtra("body", body)
            putExtra("notificationId", taskId.toString())
            action = "com.flet.dailyplanner.SHOW_REMINDER"
        }
        val pending = PendingIntent.getBroadcast(context, taskId, alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.canScheduleExactAlarms() else true
        Log.i(TAG, "canExact=$canExact, scheduling at ms=$fireAtMs")
        try {
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAtMs, pending)
                Log.i(TAG, "setExactAndAllowWhileIdle OK")
            } else {
                am.set(AlarmManager.RTC_WAKEUP, fireAtMs, pending)
                Log.i(TAG, "set (inexact) OK")
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "SecurityException, fallback to inexact: ${e.message}")
            try { am.set(AlarmManager.RTC_WAKEUP, fireAtMs, pending) }
            catch (e2: Exception) { Log.e(TAG, "both failed: ${e2.message}") }
        } catch (e: Exception) {
            Log.e(TAG, "schedule failed: ${e.message}")
        }
        try {
            val prefs = context.getSharedPreferences("ordnungen_alarms", Context.MODE_PRIVATE)
            val alarms = org.json.JSONArray(prefs.getString("alarms", "[]") ?: "[]")
            for (i in 0 until alarms.length()) {
                val alarm = alarms.getJSONObject(i)
                if (alarm.optInt("task_id", -1) == taskId) {
                    alarm.put("fire_at_ms", fireAtMs)
                    break
                }
            }
            prefs.edit().putString("alarms", alarms.toString()).apply()
            Log.i(TAG, "prefs updated")
        } catch (e: Exception) {
            Log.w(TAG, "prefs update failed: ${e.message}")
        }
    }
}
