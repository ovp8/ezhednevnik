package {{ cookiecutter.org_name_2 }}.{{ cookiecutter.package_name }}

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("ordnungen_alarms", Context.MODE_PRIVATE)
        val jsonStr = prefs.getString("alarms", "[]") ?: "[]"
        try {
            val alarms = JSONArray(jsonStr)
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val now = System.currentTimeMillis()
            val remaining = JSONArray()
            for (i in 0 until alarms.length()) {
                val alarm = alarms.getJSONObject(i)
                val fireAt = alarm.getLong("fire_at_ms")
                val taskId = alarm.getInt("task_id")
                val title = alarm.getString("title")
                val body = alarm.optString("body", "")
                val notificationId = alarm.optInt("notification_id", taskId)
                if (fireAt < now - 3600_000L) continue
                if (fireAt < now) {
                    val intentShow = Intent(context, ReminderReceiver::class.java).apply {
                        putExtra("title", "Пропущено: $title")
                        putExtra("body", body)
                        putExtra("notificationId", notificationId)
                    }
                    context.sendBroadcast(intentShow)
                    continue
                }
                val alarmIntent = Intent(context, ReminderReceiver::class.java).apply {
                    putExtra("title", title)
                    putExtra("body", body)
                    putExtra("notificationId", notificationId)
                    action = "com.flet.dailyplanner.SHOW_REMINDER"
                }
                val pendingIntent = PendingIntent.getBroadcast(context, taskId, alarmIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pendingIntent)
                remaining.put(alarm)
            }
            prefs.edit().putString("alarms", remaining.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
