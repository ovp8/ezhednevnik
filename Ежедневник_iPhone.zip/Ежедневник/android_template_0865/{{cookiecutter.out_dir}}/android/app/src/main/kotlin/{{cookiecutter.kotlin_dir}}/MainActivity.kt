package {{ cookiecutter.org_name_2 }}.{{ cookiecutter.package_name }}

import android.content.Intent
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        storeNotificationTask(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        storeNotificationTask(intent)
    }

    private fun storeNotificationTask(source: Intent?) {
        val taskId = source?.getIntExtra("task_id", -1) ?: -1
        if (taskId > 0) {
            applicationContext
                .getSharedPreferences("ordnung_notification", MODE_PRIVATE)
                .edit()
                .putInt("pending_task_id", taskId)
                .apply()
        }
    }
}
