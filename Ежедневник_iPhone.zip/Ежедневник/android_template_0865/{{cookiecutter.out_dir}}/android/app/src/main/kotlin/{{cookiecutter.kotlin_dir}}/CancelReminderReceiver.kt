package {{ cookiecutter.org_name_2 }}.{{ cookiecutter.package_name }}

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import org.json.JSONArray

class CancelReminderReceiver : BroadcastReceiver() {
    private val TAG = "CancelReminderReceiver"
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getIntExtra("task_id", 0)
        if (taskId <= 0) return
        Log.i(TAG, "onReceive task_id=$taskId")
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(taskId)
        try {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            for (tid in listOf(taskId, taskId + 1000000)) {
                val alarmIntent = Intent(context, ReminderReceiver::class.java)
                alarmIntent.action = "com.flet.dailyplanner.SHOW_REMINDER"
                val pending = PendingIntent.getBroadcast(context, tid, alarmIntent,
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
                if (pending != null) {
                    am.cancel(pending)
                    Log.i(TAG, "cancelled alarm tid=$tid")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "cancel alarms error: ${e.message}")
        }
        try {
            val prefs = context.getSharedPreferences("ordnungen_alarms", Context.MODE_PRIVATE)
            val alarms = JSONArray(prefs.getString("alarms", "[]") ?: "[]")
            val remaining = JSONArray()
            for (i in 0 until alarms.length()) {
                val alarm = alarms.getJSONObject(i)
                if (alarm.optInt("task_id", -1) != taskId) remaining.put(alarm)
            }
            prefs.edit().putString("alarms", remaining.toString())
                .putInt("cancel_request_task_id", taskId).apply()
            Log.i(TAG, "prefs updated, cancel_request_task_id=$taskId")
        } catch (e: Exception) {
            Log.w(TAG, "prefs update error: ${e.message}")
        }
    }
}
