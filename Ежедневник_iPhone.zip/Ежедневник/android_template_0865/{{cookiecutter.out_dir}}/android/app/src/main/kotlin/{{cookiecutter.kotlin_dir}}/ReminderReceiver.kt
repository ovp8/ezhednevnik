package {{ cookiecutter.org_name_2 }}.{{ cookiecutter.package_name }}

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Напоминание"
        val body = intent.getStringExtra("body") ?: ""
        val taskId = readIntExtra(intent, "task_id", readIntExtra(intent, "notificationId", 1))
        val notificationId = readIntExtra(intent, "notificationId", taskId)
        // Channel settings are immutable after first creation; this new channel migrates older silent installs.
        val channelId = "reminders_sound_v2"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        for (oldId in listOf("reminders", "reminders_v2", "reminders_v3", "reminders_v4", "reminders_alarm_v1")) {
            try { manager.deleteNotificationChannel(oldId) } catch (_: Exception) {}
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build()
            val channel = NotificationChannel(
                channelId,
                "Напоминания со звуком",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Звуковые напоминания о задачах из Ежедневника"
                enableVibration(true)
                setSound(soundUri, audioAttributes)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(channel)
        }

        val appIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("task_id", taskId)
        }
        val contentPending = PendingIntent.getActivity(
            context, notificationId, appIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val fullScreenIntent = Intent(context, ReminderFullScreenActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("title", title)
            putExtra("body", body)
            putExtra("task_id", taskId)
            putExtra("notificationId", notificationId)
        }
        val fullScreenPending = PendingIntent.getActivity(
            context, notificationId + 1_000_000, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snooze5 = makeSnooze(context, taskId, 5, title, body)
        val snooze10 = makeSnooze(context, taskId, 10, title, body)
        val cancelPending = makeCancel(context, taskId)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_reminder)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(contentPending)
            .setFullScreenIntent(fullScreenPending, true)
            .addAction(0, "5 мин", snooze5)
            .addAction(0, "10 мин", snooze10)
            .addAction(0, "Не напоминать", cancelPending)

        try {
            val compact = RemoteViews(context.packageName, R.layout.notification_reminder_small)
            compact.setTextViewText(R.id.notif_title, title)
            compact.setTextViewText(R.id.notif_body, body)

            val expanded = RemoteViews(context.packageName, R.layout.notification_reminder_expanded)
            expanded.setTextViewText(R.id.notif_title, title)
            expanded.setTextViewText(R.id.notif_body, body)
            builder.setStyle(NotificationCompat.DecoratedCustomViewStyle())
            builder.setCustomContentView(compact)
            builder.setCustomBigContentView(expanded)
            builder.setCustomHeadsUpContentView(compact)
        } catch (e: Exception) {
            e.printStackTrace()
            builder.setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText(body)
                    .setBigContentTitle(title)
            )
        }

        manager.notify(notificationId, builder.build())
    }

    private fun readIntExtra(intent: Intent, key: String, fallback: Int): Int {
        return when (val value = intent.extras?.get(key)) {
            is Int -> value
            is Long -> value.toInt()
            is String -> value.toIntOrNull() ?: fallback
            else -> fallback
        }
    }

    private fun makeSnooze(context: Context, taskId: Int, minutes: Int, title: String, body: String): PendingIntent {
        val intent = Intent(context, SnoozeReceiver::class.java).apply {
            putExtra("task_id", taskId)
            putExtra("minutes", minutes)
            putExtra("title", title)
            putExtra("body", body)
            action = "com.flet.dailyplanner.SHOW_REMINDER"
        }
        return PendingIntent.getBroadcast(
            context, taskId * 100 + minutes, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun makeCancel(context: Context, taskId: Int): PendingIntent {
        val intent = Intent(context, CancelReminderReceiver::class.java).apply {
            putExtra("task_id", taskId)
        }
        return PendingIntent.getBroadcast(
            context, taskId * 100 + 99, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
