package {{ cookiecutter.org_name_2 }}.{{ cookiecutter.package_name }}

import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class ReminderFullScreenActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.notification_full_screen)

        val title = intent.getStringExtra("title") ?: "Напоминание"
        val body = intent.getStringExtra("body") ?: ""
        val taskId = intent.getIntExtra("task_id", intent.getIntExtra("notificationId", 1))
        val notificationId = intent.getIntExtra("notificationId", taskId)

        val titleView = findViewById<TextView>(R.id.text_title)
        val bodyView = findViewById<TextView>(R.id.text_body)
        titleView.text = title
        bodyView.text = body

        findViewById<Button>(R.id.btn_snooze_5).setOnClickListener { snooze(taskId, 5, title, body) }
        findViewById<Button>(R.id.btn_snooze_10).setOnClickListener { snooze(taskId, 10, title, body) }
        findViewById<Button>(R.id.btn_cancel).setOnClickListener { cancel(taskId) }

        val root = findViewById<LinearLayout>(R.id.reminder_root)
        val touchSlop = 90f
        var downX = 0f
        var downY = 0f
        root.setOnTouchListener { _: View, event: MotionEvent ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = abs(event.rawX - downX) > touchSlop ||
                        abs(event.rawY - downY) > touchSlop
                    if (moved) dismissOnly(notificationId) else openTask(taskId)
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
        titleView.setOnClickListener { openTask(taskId) }
        bodyView.setOnClickListener { openTask(taskId) }
    }

    private fun openTask(taskId: Int) {
        val launch = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("task_id", taskId)
        }
        startActivity(launch)
        finish()
    }

    private fun dismissOnly(notificationId: Int) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.cancel(notificationId)
        finish()
    }

    private fun snooze(taskId: Int, minutes: Int, title: String, body: String) {
        val action = Intent(this, SnoozeReceiver::class.java).apply {
            putExtra("task_id", taskId)
            putExtra("minutes", minutes)
            putExtra("title", title)
            putExtra("body", body)
            action = "com.flet.dailyplanner.SHOW_REMINDER"
        }
        sendBroadcast(action)
        finish()
    }

    private fun cancel(taskId: Int) {
        val action = Intent(this, CancelReminderReceiver::class.java).apply {
            putExtra("task_id", taskId)
        }
        sendBroadcast(action)
        finish()
    }
}
