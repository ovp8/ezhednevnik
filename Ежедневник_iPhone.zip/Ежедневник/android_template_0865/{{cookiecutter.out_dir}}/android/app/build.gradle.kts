import java.util.Properties

plugins {
    id("com.android.application")
    // Kotlin is provided by the Flutter Gradle Plugin (Built-in Kotlin), so the
    // app no longer applies the Kotlin Gradle Plugin itself.
    // The Flutter Gradle Plugin must be applied after the Android Gradle plugin.
    id("dev.flutter.flutter-gradle-plugin")
}

val localProperties = Properties().apply {
    val localPropertiesFile = rootProject.file("local.properties")
    if (localPropertiesFile.exists()) {
        localPropertiesFile.inputStream().use { load(it) }
    }
}

val flutterVersionCode = localProperties.getProperty("flutter.versionCode")?.toIntOrNull() ?: 1
val flutterVersionName = localProperties.getProperty("flutter.versionName") ?: "1.0"

android {
    namespace = "{{ cookiecutter.org_name_2 }}.{{ cookiecutter.package_name }}"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    packaging {
        jniLibs {
            pickFirsts += listOf("**/libc++_shared.so")

// flet: legacy_packaging {% if cookiecutter.options.android_legacy_packaging %}
            // Legacy native-library packaging (opt-in via --android-legacy-packaging).
// flet: end of legacy_packaging {% endif %}

// flet: excluded_abis {% if cookiecutter.options.android_excluded_abis %}
            excludes += listOf({% for abi in cookiecutter.options.android_excluded_abis %}"lib/{{ abi }}/**"{% if not loop.last %}, {% endif %}{% endfor %})
// flet: end of excluded_abis {% endif %}
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    sourceSets["main"].java.srcDir("src/main/kotlin")

    {% set min_sdk_version = get_pyproject("tool.flet.android.min_sdk_version") %}
    {% set target_sdk_version = get_pyproject("tool.flet.android.target_sdk_version") %}

    defaultConfig {
        applicationId = "{{ cookiecutter.org_name_2 }}.{{ cookiecutter.package_name }}"
        val resolvedMinSdk = {{ min_sdk_version if min_sdk_version else "flutter.minSdkVersion" }}
        minSdk = resolvedMinSdk
        val resolvedTargetSdk = {{ target_sdk_version if target_sdk_version else "flutter.targetSdkVersion" }}
        targetSdk = resolvedTargetSdk
        versionCode = flutterVersionCode
        versionName = flutterVersionName

        println("Gradle build config:")
        println("  minSdkVersion: $resolvedMinSdk")
        println("  targetSdkVersion: $resolvedTargetSdk")
        println("  versionCode: $flutterVersionCode")
        println("  versionName: $flutterVersionName")

// flet: split_per_abi {% if not cookiecutter.split_per_abi %}
        ndk {
            {% if cookiecutter.options.target_arch %}
            abiFilters += listOf({% for arch in cookiecutter.options.target_arch %}"{{ arch }}"{% if not loop.last %}, {% endif %}{% endfor %})
            {% else %}
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
            {% endif %}
        }
// flet: end of split_per_abi {% endif %}
    }

// flet: android_signing {% if cookiecutter.options.android_signing %}
    signingConfigs {
        create("release") {
            keyAlias = System.getenv("FLET_ANDROID_SIGNING_KEY_ALIAS")
            keyPassword = System.getenv("FLET_ANDROID_SIGNING_KEY_PASSWORD")
            storeFile = System.getenv("FLET_ANDROID_SIGNING_KEY_STORE")?.let { file(it) }
            storePassword = System.getenv("FLET_ANDROID_SIGNING_KEY_STORE_PASSWORD")
        }
    }
// flet: end of android_signing {% endif %}

    buildTypes {
        release {
// flet: android_signing {% if cookiecutter.options.android_signing %}
            signingConfig = signingConfigs.getByName("release")
// {% else %}
            signingConfig = signingConfigs.getByName("debug")
// flet: end of android_signing {% endif %}
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
}
