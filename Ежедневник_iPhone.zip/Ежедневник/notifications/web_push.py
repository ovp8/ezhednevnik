# notifications/web_push.py
"""Web Push (VAPID) для браузеров и iPhone-PWA.

Позволяет доставлять напоминания на iPhone даже когда PWA закрыта
(iOS 16.4+, приложение установлено через Safari -> "На экран Домой").

Состав:
  - VAPID-ключи: генерируются один раз, хранятся в webpush_state.json
    рядом с БД приложения (FLET_APP_STORAGE_DATA).
  - Подписки: JSON-хранилище webpush_subscriptions.json, ключ = uid Firebase.
  - Отправка: pywebpush (aes128gcm). Битые/отписанные эндпоинты (404/410)
    удаляются автоматически.

Файл безопасно импортировать на любой платформе: тяжёлые зависимости
(pywebpush, py_vapid) подгружаются лениво и не обязательны для работы
приложения в целом.
"""
import base64
import json
import logging
import os
import threading
from datetime import datetime, timezone
from typing import List, Optional

logger = logging.getLogger(__name__)

_LOCK = threading.RLock()

# mailto в VAPID-заявке (требование протокола); можно переопределить env-ом.
_VAPID_SUBJECT = os.getenv("WEBPUSH_SUBJECT", "mailto:daily-planner@example.com")


# ---------------- Пути хранилищ ----------------

def _app_data_dir() -> str:
    env = os.getenv("FLET_APP_STORAGE_DATA")
    if env:
        return env
    # по умолчанию — каталог проекта (на уровень выше notifications/)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _state_path() -> str:
    return os.path.join(_app_data_dir(), "webpush_state.json")


def _subs_path() -> str:
    return os.path.join(_app_data_dir(), "webpush_subscriptions.json")


# ---------------- VAPID-ключи ----------------

def _load_or_create_vapid() -> dict:
    """Возвращает {'private_pem': str, 'public_key_b64url': str} (создаёт при первом вызове)."""
    with _LOCK:
        path = _state_path()
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    state = json.load(f)
                if state.get("private_pem") and state.get("public_key_b64url"):
                    return state
            except Exception as ex:
                logger.warning("[webpush] state read error: %s", ex)

        # P-256 (SECP256R1) — единственная кривая, допустимая в Web Push.
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ec

        priv = ec.generate_private_key(ec.SECP256R1())
        private_pem = priv.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode("ascii")
        # 65-байтовая несжатая точка (X9.62) — то, что ждёт браузерный
        # applicationServerKey после urlBase64ToUint8Array.
        raw_point = priv.public_key().public_bytes(
            encoding=serialization.Encoding.X962,
            format=serialization.PublicFormat.UncompressedPoint,
        )
        public_b64 = base64.urlsafe_b64encode(raw_point).rstrip(b"=").decode("ascii")

        state = {"private_pem": private_pem, "public_key_b64url": public_b64}
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2)
        os.replace(tmp, path)
        logger.info("[webpush] VAPID keys generated -> %s", path)
        return state


def get_vapid_public_key() -> str:
    """Base64url публичный ключ applicationServerKey для браузера."""
    return _load_or_create_vapid()["public_key_b64url"]


def get_vapid_private_pem() -> str:
    return _load_or_create_vapid()["private_pem"]


def get_vapid_subject() -> str:
    return _VAPID_SUBJECT


# ---------------- Подписки ----------------

def _iso_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _load_subs() -> List[dict]:
    path = _subs_path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception as ex:
        logger.warning("[webpush] subscriptions read error: %s", ex)
        return []


def _save_subs(subs: List[dict]):
    path = _subs_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(subs, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def _sub_key(sub: dict) -> str:
    return (sub.get("endpoint") or "").rstrip("/")[-120:]


def add_subscription(uid: str, subscription: dict) -> bool:
    """Сохраняет подписку браузера. Возвращает True, если добавлена новая."""
    if not subscription or not subscription.get("endpoint"):
        return False
    with _LOCK:
        subs = _load_subs()
        key = _sub_key(subscription)
        for s in subs:
            if _sub_key(s) == key:
                # обновляем uid/keys, если эндпоинт уже известен
                if s.get("uid") != uid:
                    s["uid"] = uid
                    _save_subs(subs)
                return False
        subs.append({
            "uid": uid or "",
            "endpoint": subscription.get("endpoint"),
            "keys": subscription.get("keys") or {},
            "created_at": _iso_now(),
        })
        _save_subs(subs)
        logger.info("[webpush] subscription added (uid=%s, total=%d)", uid, len(subs))
        return True


def remove_subscription(endpoint: str) -> bool:
    with _LOCK:
        subs = _load_subs()
        before = len(subs)
        key = (endpoint or "").rstrip("/")[-120:]
        subs = [s for s in subs if _sub_key(s) != key]
        if len(subs) != before:
            _save_subs(subs)
            return True
        return False


def get_subscriptions(uid: str) -> List[dict]:
    """Подписки конкретного uid; при uid="" — только непривязанные."""
    with _LOCK:
        return [s for s in _load_subs() if (s.get("uid") or "") == (uid or "")]


def count_subscriptions(uid: Optional[str] = None) -> int:
    with _LOCK:
        if uid is None:
            return len(_load_subs())
        return len(get_subscriptions(uid))


def _drop_subscription(endpoint: str):
    try:
        remove_subscription(endpoint)
    except Exception as ex:
        logger.warning("[webpush] drop subscription error: %s", ex)


# ---------------- Отправка ----------------

def send_to_uid(uid: str, title: str, body: str,
                extra: Optional[dict] = None) -> dict:
    """
    Отправляет Web Push всем подпискам пользователя (и непривязанным).

    Возвращает {'sent': int, 'failed': int, 'dropped': int}.
    Не бросает исключений — сбой доставки не должен ломать приложение.
    """
    result = {"sent": 0, "failed": 0, "dropped": 0}
    extra = extra or {}
    try:
        targets = get_subscriptions(uid or "")
        if (uid or "") != "":
            targets = targets + get_subscriptions("")  # непривязанные тоже получают
    except Exception as ex:
        logger.warning("[webpush] list subscriptions error: %s", ex)
        return result

    if not targets:
        return result

    payload = json.dumps({
        "title": title or "Ежедневник",
        "body": body or "",
        "tag": f"task-{extra.get('task_id') or extra.get('id') or ''}",
        "task_id": extra.get("task_id") or extra.get("id") or 0,
        "url": "/",
    }, ensure_ascii=False)

    private_pem = get_vapid_private_pem()
    claims = {"sub": _VAPID_SUBJECT}

    from pywebpush import WebPusher, WebPushException

    for sub in targets:
        info = {"endpoint": sub.get("endpoint"), "keys": sub.get("keys") or {}}
        if not info["endpoint"] or not info["keys"]:
            result["dropped"] += 1
            continue
        try:
            resp = WebPusher(info).send_request(
                data=payload.encode("utf-8") if isinstance(payload, str) else payload,
                vapid_private_key=private_pem,
                vapid_claims=claims,
                ttl=86400 * 7,
            )
            if resp is not None and getattr(resp, "status_code", 200) >= 400:
                code = resp.status_code
                logger.warning("[webpush] endpoint status %s", code)
                if code in (404, 410):
                    _drop_subscription(info["endpoint"])
                    result["dropped"] += 1
                else:
                    result["failed"] += 1
            else:
                result["sent"] += 1
        except WebPushException as ex:
            code = getattr(getattr(ex, "response", None), "status_code", None)
            if code in (404, 410):
                _drop_subscription(info["endpoint"])
                result["dropped"] += 1
            else:
                logger.warning("[webpush] send error: %s", ex)
                result["failed"] += 1
        except Exception as ex:
            logger.warning("[webpush] unexpected send error: %s", ex)
            result["failed"] += 1

    if result["sent"] or result["failed"] or result["dropped"]:
        logger.info("[webpush] delivery uid=%s: %s", uid, result)
    return result
