# repository/task_repository.py
"""Фасад для UI. Логика повторов и напоминаний — здесь."""
from datetime import datetime, timedelta, timezone
from typing import Optional
from db.local_db import LocalDB, CATEGORY_DEFAULT, CATEGORY_VALUES
from recurrence import next_occurrence_datetime
from notifications.alarm_manager import schedule_alarm, cancel_alarm


def _parse_task_dt(dt_str: str) -> Optional[datetime]:
    """Парсит 'YYYY-MM-DD HH:MM' как ЛОКАЛЬНОЕ время."""
    try:
        return datetime.strptime(dt_str.strip(), "%Y-%m-%d %H:%M")
    except Exception:
        return None


class TaskRepository:
    def __init__(self, db: LocalDB, session=None, reminder_storage=None):
        self.db = db
        self.session = session
        self.reminders = reminder_storage

    @property
    def _uid(self):
        return self.session.uid if self.session else None

    def _user_tzinfo(self):
        """Часовой пояс пользователя (Настройки -> iPhone/PWA).

        None — время считается локальным для устройства, где работает код:
        на Android это TZ телефона, на веб-сервере — TZ сервера. Для PWA
        на iPhone TZ приходит с устройства и сохраняется через /api/push/*
        либо выбирается вручную в Настройках.
        """
        try:
            name = (self.get_setting("user_timezone", "") or "").strip()
            if not name:
                return None
            from zoneinfo import ZoneInfo
            return ZoneInfo(name)
        except Exception as ex:
            print(f"[repo] user_timezone error: {ex}")
            return None

    # ---------------- Задачи ----------------

    def add_task(self, task, priority=3, datetime_str=None,
                 details=None, repeat=None, note=None,
                 category: Optional[str] = None) -> int:
        if category not in CATEGORY_VALUES:
            category = CATEGORY_DEFAULT
        return self.db.add_task(
            task=task, priority=priority, datetime_str=datetime_str,
            details=details, repeat=repeat, note=note,
            user_id=self._uid, category=category,
        )

    def get_task(self, task_id):
        return self.db.get_task(task_id)

    def get_tasks_for_day(self, date_str, category: Optional[str] = None):
        return self.db.get_tasks_for_day(
            date_str, user_id=self._uid,
            category=(category if category in CATEGORY_VALUES else None),
        )

    def get_all_tasks(self, category: Optional[str] = None):
        return self.db.get_all_tasks(
            user_id=self._uid,
            category=(category if category in CATEGORY_VALUES else None),
        )

    def update_task(self, task_id, **fields) -> bool:
        return self.db.update_task(task_id, **fields)

    def toggle_task_status(self, task_id):
        task = self.db.get_task(task_id)
        if not task:
            return False
        was_done = task["status"] == 1
        new_status = 0 if was_done else 1

        # Синхронизируем детализацию с новым статусом
        details = list(task.get("details") or [])
        if details:
            for d in details:
                if isinstance(d, dict):
                    d["done"] = (new_status == 1)
            self.db.update_task(task_id, status=new_status, details=details)
        else:
            self.db.update_task(task_id, status=new_status)

        if not was_done and new_status == 1:
            saved_cfg = None
            try:
                saved_cfg = self.get_reminder_config(task_id)
            except Exception as ex:
                print(f"[repo] save reminder cfg error: {ex}")

            self.clear_reminder(task_id)

            # ⚠️ ФИКС: если задача уже обрабатывалась через диалог просрочки,
            # не создаём повтор вручную (иначе будет дубликат)
            if not task.get("last_warned_at"):
                self._create_next_occurrence(task, saved_reminder_cfg=saved_cfg)
            else:
                print(f"[repo] task {task_id} already resolved via overdue dialog, skip next occurrence")
        return True

    def mark_task_complete(self, task_id, details=None):
        task = self.db.get_task(task_id)
        if not task:
            return False
        was_done = task["status"] == 1
        fields = {"status": 1}
        if details is not None:
            fields["details"] = details
        self.db.update_task(task_id, **fields)
        if not was_done:
            saved_cfg = None
            try:
                saved_cfg = self.get_reminder_config(task_id)
            except Exception as ex:
                print(f"[repo] save reminder cfg error: {ex}")
            self.clear_reminder(task_id)
            
            # ⚠️ ФИКС: аналогичная проверка
            if not task.get("last_warned_at"):
                self._create_next_occurrence(task, saved_reminder_cfg=saved_cfg)
            else:
                print(f"[repo] task {task_id} already resolved via overdue dialog, skip next occurrence")
        return True

    def delete_task(self, task_id):
        # 1. Сначала принудительно чистим все возможные напоминания
        if self.reminders:
            self.reminders.delete_for_task(task_id)
        
        # 2. Отменяем Android-будильники (оба типа: заранее и в момент)
        try:
            from notifications.alarm_manager import cancel_alarm
            cancel_alarm(task_id)
            cancel_alarm(task_id + 1000000)
        except Exception as ex:
            print(f"[repo] cancel_alarm error: {ex}")

        # 3. Удаляем саму задачу из БД
        return self.db.delete_task(task_id)

    def carry_over_uncompleted_singles(self):
        """Переносит невыполненные разовые задачи с прошлых дней на сегодня."""
        now = datetime.now()
        today_str = now.strftime("%Y-%m-%d")
        
        with self.db._lock:
            cur = self.db.conn.execute(
                """SELECT * FROM tasks
                   WHERE is_deleted = 0
                     AND status = 0
                     AND (repeat IS NULL OR repeat = '')
                     AND datetime IS NOT NULL
                     AND datetime != ''
                     AND datetime < ?
                     AND (user_id = ? OR user_id IS NULL)""",
                (f"{today_str} 00:00", self._uid),
            )
            tasks = [self.db._task_row_to_dict(r) for r in cur.fetchall()]

        for t in tasks:
            old_dt = t.get("datetime")
            try:
                # Сохраняем время, но меняем дату на сегодня
                time_part = old_dt.split(" ")[1] if " " in old_dt else "09:00"
                new_dt_str = f"{today_str} {time_part}"
                
                # Обновляем время задачи
                self.update_task(t["id"], datetime=new_dt_str)
                
                # Помечаем флагом переноса (локально)
                with self.db._lock:
                    self.db.conn.execute(
                        "UPDATE tasks SET carried_over = 1 WHERE id = ?",
                        (t["id"],)
                    )
                    self.db.conn.commit()
                    
                print(f"[carry_over] task {t['id']} moved to {new_dt_str}")
            except Exception as ex:
                print(f"[carry_over] error for task {t['id']}: {ex}")

    # ---------------- Просроченные повторяющиеся задачи ----------------

    _THRESHOLDS = {
        "hourly":  timedelta(hours=1),
        "daily":   timedelta(days=1),
        "days":    timedelta(days=1),
        "monthly": timedelta(days=3),
        "yearly":  timedelta(days=30),
    }

    def _next_occurrence_after_now(self, task: dict, max_iters: int = 400) -> Optional[datetime]:
        """Возвращает ближайшую дату повтора строго > now.
        Итерируем next_occurrence_datetime, пока не уйдём в будущее —
        чтобы не создать новый экземпляр в прошлом при сильном пропуске."""
        repeat = task.get("repeat")
        if not isinstance(repeat, dict):
            return None
        dt_str = task.get("datetime") or ""
        base = _parse_task_dt(dt_str)
        if base is None:
            return None

        now = datetime.now()
        cur_task = dict(task)
        cur_dt = base
        for _ in range(max_iters):
            cur_task["datetime"] = cur_dt.strftime("%Y-%m-%d %H:%M")
            nxt = next_occurrence_datetime(cur_task)
            if nxt is None:
                return None
            if nxt > now:
                return nxt
            cur_dt = nxt
        return None

    def get_overdue_recurring_tasks(self) -> list:
        """
        Возвращает задачи, которые:
          - status = 0
          - repeat задан
          - просрочены больше порога (зависит от типа повтора)
          - не показывались пользователю последние 24 часа (last_warned_at)
        """
        now = datetime.now()
        cooldown = now - timedelta(hours=24)
        cooldown_iso = cooldown.astimezone(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

        with self.db._lock:
            cur = self.db.conn.execute(
                """SELECT * FROM tasks
                   WHERE is_deleted = 0
                     AND status = 0
                     AND repeat IS NOT NULL
                     AND datetime IS NOT NULL
                     AND datetime != ''
                     AND (last_warned_at IS NULL OR last_warned_at < ?)
                   ORDER BY datetime ASC""",
                (cooldown_iso,),
            )
            rows = [self.db._task_row_to_dict(r) for r in cur.fetchall()]

        result = []
        for t in rows:
            repeat = t.get("repeat")
            if not isinstance(repeat, dict):
                continue
            rtype = repeat.get("type")
            threshold = self._THRESHOLDS.get(rtype)
            if threshold is None:
                continue
            task_dt = _parse_task_dt(t.get("datetime") or "")
            if task_dt is None:
                continue
            if (now - task_dt) > threshold:
                result.append(t)
        return result

    def _set_last_warned_at(self, task_id: int):
        """Локальная метаинформация — не триггерит sync."""
        now_iso = datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        with self.db._lock:
            self.db.conn.execute(
                "UPDATE tasks SET last_warned_at = ? WHERE id = ?",
                (now_iso, task_id),
            )
            self.db.conn.commit()

    def resolve_overdue_task(self, task_id: int, completed: bool) -> bool:
        """
        Обрабатывает просроченную задачу.
        completed=True: отметить как выполненную.
        completed=False: оставить status=0 (в истории), но создать следующий
                         экземпляр и больше её не показывать в диалоге.
        В обоих случаях создаёт следующий экземпляр (с датой строго > now)
        и копирует напоминание.
        """
        task = self.db.get_task(task_id)
        if not task:
            return False

        # 1. Запоминаем конфиг напоминания ДО любых изменений
        try:
            saved_cfg = self.get_reminder_config(task_id)
        except Exception as ex:
            print(f"[repo] resolve_overdue save cfg error: {ex}")
            saved_cfg = None

        # 2. Если completed — отмечаем выполненной (без запуска _create_next_occurrence,
        #    потому что следующую дату считаем по-другому)
        if completed:
            details = list(task.get("details") or [])
            for d in details:
                if isinstance(d, dict):
                    d["done"] = True
            self.db.update_task(task_id, status=1, details=details)
            self.clear_reminder(task_id)
        else:
            # Вариант A: оставляем status=0 в истории, но помечаем как «обработанную»
            # и снимаем напоминание (иначе оно будет спамить)
            self.clear_reminder(task_id)

        # 3. Помечаем last_warned_at — больше не всплывёт в диалоге 24 часа
        self._set_last_warned_at(task_id)

        # 4. Создаём следующий экземпляр с датой строго > now
        try:
            next_dt = self._next_occurrence_after_now(task)
            if next_dt is not None:
                self._create_occurrence_at(task, next_dt, saved_cfg)
        except Exception as ex:
            print(f"[repo] resolve_overdue create next error: {ex}")

        return True

    def _create_occurrence_at(self, task: dict, next_dt: datetime,
                              saved_reminder_cfg=None):
        """Создаёт экземпляр повторяющейся задачи на конкретную дату."""
        next_dt_str = next_dt.strftime("%Y-%m-%d %H:%M")
        date_part = next_dt.strftime("%Y-%m-%d")
        try:
            same_day = self.db.get_tasks_for_day(date_part, user_id=self._uid)
        except Exception:
            same_day = []
        task_text = (task.get("task") or "").strip()
        for t in same_day:
            t_text = (t.get("task") or "").strip()
            t_dt = t.get("datetime") or ""
            if t_text == task_text and t_dt == next_dt_str:
                print(f"[repo] occurrence already exists at {next_dt_str}, skip")
                return

        details = list(task.get("details") or [])
        for d in details:
            if isinstance(d, dict):
                d["done"] = False

        new_id = self.db.add_task(
            task=task.get("task", ""),
            priority=int(task.get("priority") or 3),
            datetime_str=next_dt_str,
            details=details,
            repeat=task.get("repeat"),
            note=task.get("note"),
            user_id=self._uid,
            category=task.get("category", CATEGORY_DEFAULT),
        )

        # Копируем напоминания
        try:
            copy_enabled = (self.get_setting("copy_reminder_on_repeat", "1") or "1") == "1"
            if not copy_enabled:
                return
            cfg = saved_reminder_cfg
            if cfg and (cfg.get("before") or cfg.get("at_time")):
                self.set_reminders(
                    new_id,
                    before_min=cfg.get("before"),
                    at_time=bool(cfg.get("at_time")),
                    repeat=bool(cfg.get("repeat")),
                    repeat_interval=int(cfg.get("repeat_interval") or 5),
                    repeat_max=int(cfg.get("repeat_max") or 4),
                )
                print(f"[repo] copied reminders to occurrence {new_id} at {next_dt_str}")
        except Exception as ex:
            print(f"[repo] copy reminders to occurrence error: {ex}")

    def count_pending_sync(self):
        return len(self.db.get_unsynced_tasks())

    # ---------------- Напоминания ----------------

    def set_reminders(self, task_id: int,
                      before_min: Optional[int] = None,
                      at_time: bool = False,
                      repeat: bool = False,
                      repeat_interval: int = 5,
                      repeat_max: int = 4) -> dict:
        """
        Устанавливает напоминания задачи.
        Возвращает dict-статус:
          {'before_requested': bool, 'before_set': bool,
           'at_time_requested': bool, 'at_time_set': bool}
        Если *_requested=True, а *_set=False — значит время в прошлом.
        """
        status = {
            "before_requested": (before_min is not None and int(before_min) > 0),
            "before_set": False,
            "at_time_requested": bool(at_time),
            "at_time_set": False,
        }

        if not self.reminders:
            return status

        self.reminders.delete_for_task(task_id)
        cancel_alarm(task_id)

        if before_min is None and not at_time:
            return status

        task = self.db.get_task(task_id)
        if not task:
            return status

        dt_str = task.get("datetime") or ""
        task_dt_naive = _parse_task_dt(dt_str)
        if task_dt_naive is None:
            print(f"[reminder] cannot parse datetime: {dt_str!r}")
            return status

        # Часовой пояс пользователя: явно заданный (PWA) или локальный
        user_tz = self._user_tzinfo()
        if user_tz is not None:
            task_dt_local = task_dt_naive.replace(tzinfo=user_tz)
        else:
            task_dt_local = task_dt_naive.astimezone()
        now_utc = datetime.now(timezone.utc)

        rep_interval = max(1, int(repeat_interval or 5)) if repeat else 0
        rep_max = max(1, int(repeat_max or 4)) if repeat else 0

        # --- 1. Напоминание "заранее" ---
        if before_min is not None and int(before_min) > 0:
            fire_at_utc = (task_dt_local - timedelta(minutes=int(before_min))
                           ).astimezone(timezone.utc)
            if fire_at_utc > now_utc:
                fire_at_str = fire_at_utc.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
                self.reminders.add_full(
                    task_id=task_id, task_text=task.get("task", ""),
                    fire_at=fire_at_str, minutes_before=int(before_min),
                    kind="before",
                    repeat_interval_min=rep_interval,
                    repeat_max=rep_max,
                    repeat_count=0,
                )
                schedule_alarm(
                    task_id=task_id, fire_at_utc=fire_at_utc,
                    title=f"Через {before_min} мин",
                    body=task.get("task", ""),
                )
                status["before_set"] = True
                print(f"[reminder] set 'before' task_id={task_id} at {fire_at_str}")
            else:
                print(f"[reminder] skip 'before': fire time in past")

        # --- 2. Напоминание "в момент события" ---
        if at_time:
            fire_at_utc = task_dt_local.astimezone(timezone.utc)
            if fire_at_utc > now_utc:
                fire_at_str = fire_at_utc.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
                self.reminders.add_full(
                    task_id=task_id, task_text=task.get("task", ""),
                    fire_at=fire_at_str, minutes_before=0,
                    kind="at_time",
                    repeat_interval_min=rep_interval,
                    repeat_max=rep_max,
                    repeat_count=0,
                )
                schedule_alarm(
                    task_id=task_id + 1000000,
                    fire_at_utc=fire_at_utc,
                    title="Пора начинать",
                    body=task.get("task", ""),
                    notification_id=task_id,
                )
                status["at_time_set"] = True
                print(f"[reminder] set 'at_time' task_id={task_id} at {fire_at_str}")
            else:
                print(f"[reminder] skip 'at_time': fire time in past")

        return status

    def set_reminder(self, task_id: int, minutes: Optional[int]) -> bool:
        """Старый API. Оставлен для совместимости."""
        if minutes is None or minutes <= 0:
            self.set_reminders(task_id, before_min=None, at_time=False)
            return True
        self.set_reminders(task_id, before_min=int(minutes), at_time=False)
        return True

    def get_reminder_config(self, task_id: int) -> dict:
        if not self.reminders:
            return {"before": None, "at_time": False, "repeat": False,
                    "repeat_interval": 5, "repeat_max": 4}
        try:
            return self.reminders.get_config(task_id)
        except Exception as ex:
            print(f"[repo] get_reminder_config error: {ex}")
            return {"before": None, "at_time": False, "repeat": False,
                    "repeat_interval": 5, "repeat_max": 4}

    def get_reminder_minutes(self, task_id: int) -> Optional[int]:
        if not self.reminders:
            return None
        rs = self.reminders.get_for_task(task_id)
        for r in rs:
            if (r.get("kind") or "before") == "before":
                return int(r.get("minutes_before", 0) or 0)
        return None

    def clear_reminder(self, task_id: int):
        if self.reminders:
            self.reminders.delete_for_task(task_id)
        cancel_alarm(task_id)
        cancel_alarm(task_id + 1000000)

    def get_task_ids_with_reminders(self) -> set:
        if not self.reminders:
            return set()
        try:
            with self.db._lock:
                cur = self.db.conn.execute(
                    "SELECT DISTINCT task_id FROM reminders WHERE fired = 0"
                )
                return {row["task_id"] for row in cur.fetchall()}
        except Exception as ex:
            print(f"[repo] get_task_ids_with_reminders error: {ex}")
            return set()

    def refresh_reminders_tz(self) -> int:
        """Перестраивает напоминания будущих задач под ТЕКУЩИЙ user_timezone.

        Вызывается после смены часового пояса в настройках (iPhone/PWA):
        пересчитывает fire_at всех несработавших напоминаний относительно
        времени задач. Возвращает количество обновлённых задач.
        """
        if not self.reminders:
            return 0
        task_ids = sorted(self.get_task_ids_with_reminders())
        if not task_ids:
            return 0
        updated = 0
        for tid in task_ids:
            try:
                cfg = self.get_reminder_config(tid)
                if not (cfg.get("before") or cfg.get("at_time")):
                    continue
                status = self.set_reminders(
                    tid,
                    before_min=cfg.get("before"),
                    at_time=bool(cfg.get("at_time")),
                    repeat=bool(cfg.get("repeat")),
                    repeat_interval=int(cfg.get("repeat_interval") or 5),
                    repeat_max=int(cfg.get("repeat_max") or 4),
                )
                if status.get("before_set") or status.get("at_time_set"):
                    updated += 1
            except Exception as ex:
                print(f"[repo] refresh reminders task {tid} error: {ex}")
        print(f"[repo] refresh_reminders_tz: updated {updated}/{len(task_ids)}")
        return updated

    # ---------------- Повторы ----------------

    def _create_next_occurrence(self, task: dict, saved_reminder_cfg=None):
        repeat = task.get("repeat")
        if not isinstance(repeat, dict):
            return
        next_dt = next_occurrence_datetime(task)
        if next_dt is None:
            return
        next_dt_str = next_dt.strftime("%Y-%m-%d %H:%M")
        date_part = next_dt.strftime("%Y-%m-%d")
        try:
            same_day = self.db.get_tasks_for_day(date_part, user_id=self._uid)
        except Exception:
            same_day = []
        task_text = (task.get("task") or "").strip()
        for t in same_day:
            t_text = (t.get("task") or "").strip()
            t_dt = t.get("datetime") or ""
            if t_text == task_text and t_dt == next_dt_str:
                return
        details = list(task.get("details") or [])
        for d in details:
            if isinstance(d, dict):
                d["done"] = False
        new_id = self.db.add_task(
            task=task.get("task", ""),
            priority=int(task.get("priority") or 3),
            datetime_str=next_dt_str,
            details=details,
            repeat=task.get("repeat"),
            note=task.get("note"),
            user_id=self._uid,
            category=task.get("category", CATEGORY_DEFAULT),
        )

        # Копируем настройки напоминания в новую задачу
        try:
            copy_enabled = (self.get_setting("copy_reminder_on_repeat", "1") or "1") == "1"
            if not copy_enabled:
                print(f"[repo] copy reminder disabled by setting")
                return
            # Если передан saved_reminder_cfg — используем его (актуально при toggle/complete),
            # иначе читаем из БД
            if saved_reminder_cfg is not None:
                cfg = saved_reminder_cfg
            else:
                cfg = self.get_reminder_config(task["id"])
            if cfg.get("before") or cfg.get("at_time"):
                self.set_reminders(
                    new_id,
                    before_min=cfg.get("before"),
                    at_time=bool(cfg.get("at_time")),
                    repeat=bool(cfg.get("repeat")),
                    repeat_interval=int(cfg.get("repeat_interval") or 5),
                    repeat_max=int(cfg.get("repeat_max") or 4),
                )
                print(f"[repo] copied reminders from {task['id']} to {new_id}")
        except Exception as ex:
            print(f"[repo] copy reminders error: {ex}")

    # ---------------- Настройки / счётчики ----------------

    def get_setting(self, key, default=None):
        return self.db.get_setting(key, default)

    def set_setting(self, key, value):
        self.db.set_setting(key, value)

    def count_by_category(self, date_str: str) -> dict:
        all_tasks = self.get_tasks_for_day(date_str)
        result = {"personal": 0, "work": 0, "other": 0, "total": len(all_tasks)}
        for t in all_tasks:
            cat = t.get("category", CATEGORY_DEFAULT)
            if cat in result:
                result[cat] += 1
        return result