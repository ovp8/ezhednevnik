# ui/theme.py
"""Две палитры и применение темы к page."""
import flet as ft


DARK = {
    "name": "dark",
    "bg": "#0F1115",
    "surface": "#1A1D24",
    "surface2": "#232830",
    "surface3": "#2D3340",
    "accent": "#4F8CFF",
    "accent_text": "#FFFFFF",
    "text": "#E6E8EB",
    "text_muted": "#8892A0",
    "border": "#2A2F38",
    "success": "#3FBF7F",
    "danger": "#E5484D",
    "warning": "#F5A623",
    "shadow": "#000000",
    "shadow_alpha": "66",  # hex alpha
    "priority": ["#8892A0", "#7B8594", "#4F8CFF", "#F5A623", "#E5484D"],
}

LIGHT = {
    "name": "light",
    "bg": "#F0F2F5",
    "surface": "#FFFFFF",
    "surface2": "#F7F8FA",
    "surface3": "#EAECEF",
    "accent": "#2E6BEA",
    "accent_text": "#FFFFFF",
    "text": "#1A1D24",
    "text_muted": "#5A6472",
    "border": "#DCE0E5",
    "success": "#2EA36A",
    "danger": "#D93A3F",
    "warning": "#E09515",
    "shadow": "#000000",
    "shadow_alpha": "22",
    "priority": ["#8892A0", "#5A6472", "#2E6BEA", "#E09515", "#D93A3F"],
}

THEMES = {"dark": DARK, "light": LIGHT}


def get_palette(name: str) -> dict:
    return THEMES.get(name, DARK)


def apply_theme(page: ft.Page, name: str, update=True):
    """Применить тему. Тёмная по умолчанию."""
    p = get_palette(name)
    page.bgcolor = p["bg"]
    page.theme_mode = ft.ThemeMode.DARK if name == "dark" else ft.ThemeMode.LIGHT
    try:
        page.theme = ft.Theme(color_scheme_seed=p["accent"])
    except Exception:
        pass
    try:
        if update:
            page.update()
    except Exception:
        pass


def toggle_theme_name(current: str) -> str:
    return "light" if current == "dark" else "dark"