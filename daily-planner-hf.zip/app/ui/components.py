# ui/components.py
"""Переиспользуемые стилизованные компоненты. Только Padding.only."""
import flet as ft


def elevated_button(
    label, on_click, palette, primary=False, danger=False,
    icon=None, expand=False, disabled=False, center_content=False, compact=False,
):
    if disabled:
        bg_gradient = ["#555555", "#333333"]
        fg = "#AAAAAA"
        border_color = "#888888"
    elif danger:
        bg_gradient = ["#8A3A3A", "#4A1C1C"]  # Красный глянец
        fg = "#FFFFFF"
        border_color = "#FFFFFF"
    elif primary:
        bg_gradient = ["#4A6B8A", "#2E4964"]  # Синий глянец
        fg = "#FFFFFF"
        border_color = "#FFFFFF"
    else:
        bg_gradient = ["#3A5673", "#1C2D41"]  # Тёмный глянец
        fg = "#FFFFFF"
        border_color = "#FFFFFF"

    parts = []
    if icon:
        parts.append(ft.Text(icon, color=fg, size=16))
    
    parts.append(ft.Text(
        label, 
        color=fg, 
        size=12 if compact else 14, 
        weight=ft.FontWeight.W_600,
        max_lines=1 if compact else 2,
        no_wrap=compact,
        text_align=ft.TextAlign.CENTER,
        expand=center_content,
    ))

    content = ft.Row(
        controls=parts,
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=6, tight=not center_content,
    )

    container = ft.Container(
        content=content,
        padding=ft.Padding.only(
            left=5 if compact else 12,
            top=7 if compact else 10,
            right=5 if compact else 12,
            bottom=7 if compact else 10,
        ),
        border_radius=14,
        border=ft.Border.all(1, border_color),
        gradient=ft.LinearGradient(
            begin=ft.Alignment.TOP_CENTER,
            end=ft.Alignment.BOTTOM_CENTER,
            colors=bg_gradient,
        ),
        on_click=None if disabled else on_click,
        shadow=ft.BoxShadow(
            blur_radius=6, spread_radius=0,
            color="#000000AA",
            offset=ft.Offset(0, 4),
        ),
        animate=ft.Animation(120, ft.AnimationCurve.EASE_OUT),
        ink=True,
    )
    if expand:
        container.expand = True
    return container


def card(content, palette, padding=14, on_click=None, margin_bottom=10):
    return ft.Container(
        content=content,
        bgcolor=palette["surface"],
        border_radius=16,
        padding=padding,
        margin=ft.Margin.only(bottom=margin_bottom),
        shadow=ft.BoxShadow(
            blur_radius=10, spread_radius=0,
            color=palette["shadow"] + palette["shadow_alpha"],
            offset=ft.Offset(0, 3),
        ),
        on_click=on_click,
        animate=ft.Animation(120, ft.AnimationCurve.EASE_OUT),
        ink=bool(on_click),
    )


def emoji_button(emoji, on_click, palette, size=42, bg=None):
    bg = bg or palette["surface3"]
    return ft.Container(
        content=ft.Text(emoji, size=18, color=palette["text"]),
        width=size, height=size,
        bgcolor=bg,
        border_radius=size // 2,
        alignment=ft.Alignment.CENTER,
        on_click=on_click,
        ink=True,
    )


def title_text(text, palette, size=22):
    return ft.Text(text, color=palette["text"], size=size, weight=ft.FontWeight.W_700)


def body_text(text, palette, size=15, muted=False):
    return ft.Text(
        text,
        color=palette["text_muted"] if muted else palette["text"],
        size=size,
    )


def styled_field(label, palette, password=False, multiline=False,
                 value="", hint=None, keyboard_type=None):
    """Поле ввода. ВАЖНО: content_padding, НЕ padding."""
    return ft.TextField(
        label=label,
        value=value,
        password=password,
        multiline=multiline,
        hint_text=hint,
        keyboard_type=keyboard_type,
        bgcolor=palette["surface2"],
        color=palette["text"],
        border_color=palette["border"],
        focused_border_color=palette["accent"],
        label_style=ft.TextStyle(color=palette["text_muted"], size=13),
        cursor_color=palette["accent"],
        border_radius=12,
        border=ft.InputBorder.OUTLINE,
        content_padding=ft.Padding.only(left=14, top=12, right=14, bottom=12),
    )


def divider(palette):
    return ft.Container(
        height=1,
        bgcolor=palette["border"],
        margin=ft.Margin.only(top=10, bottom=10),
    )


def snack(page, text, palette, error=False):
    color = palette["danger"] if error else palette["success"]
    page.snack_bar = ft.SnackBar(
        content=ft.Text(text, color="#FFFFFF"),
        bgcolor=color,
        duration=2500,
    )
    page.snack_bar.open = True
    page.update()