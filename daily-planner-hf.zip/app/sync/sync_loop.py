# sync/sync_loop.py
import asyncio
from typing import Callable, Optional, Any
from cloud.session_manager import SessionManager
from cloud.firestore_client import FirestoreClient
from sync.sync_manager import sync_once, SyncResult
from sync.network_cache import invalidate_network_cache


DEFAULT_INTERVAL = 180
MIN_INTERVAL = 30
MAX_INTERVAL = 24 * 3600   # 24 часа — защита от абсурда
SLEEP_CHUNK = 20           # разбиение sleep для быстрой реакции на смену настроек


def _get_sync_enabled(db: Any) -> bool:
    # В режиме распространения автосинхронизация всегда выключена
    try:
        from config import DISTRIBUTION_MODE
        if DISTRIBUTION_MODE:
            return False
    except Exception:
        pass

    try:
        v = db.get_setting("sync_enabled", "0") or "0"
        return v == "1"
    except Exception:
        return False


def _get_sync_interval(db: Any, fallback: int = DEFAULT_INTERVAL) -> int:
    try:
        v = db.get_setting("sync_interval", str(fallback)) or str(fallback)
        n = int(v)
        if n < MIN_INTERVAL:
            n = MIN_INTERVAL
        if n > MAX_INTERVAL:
            n = MAX_INTERVAL
        return n
    except Exception:
        return fallback


class SyncLoop:
    def __init__(
        self,
        db: Any,
        session: SessionManager,
        interval: int = DEFAULT_INTERVAL,
        on_result: Optional[Callable[[SyncResult], None]] = None,
        on_error: Optional[Callable[[Exception], None]] = None,
        pull_on_tick: bool = False,
    ):
        self.db = db
        self.session = session
        self.interval = interval
        self.on_result = on_result
        self.on_error = on_error
        self.pull_on_tick = pull_on_tick
        self._task: Optional[asyncio.Task] = None
        self._stop_flag = False
        self._sync_lock: Optional[asyncio.Lock] = None

    def _get_lock(self) -> asyncio.Lock:
        if self._sync_lock is None:
            self._sync_lock = asyncio.Lock()
        return self._sync_lock

    def start(self):
        if self._task and not self._task.done():
            return
        self._stop_flag = False
        self._task = asyncio.create_task(self._run())
        print("[sync_loop] started")

    async def stop(self):
        self._stop_flag = True
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
        self._task = None
        print("[sync_loop] stopped")

    def request_stop(self):
        """Синхронная остановка «по флагу»: безопасна, когда event loop сессии
        уже недоступен (закрытие страницы, GC сессии). Задача выйдет сама
        на ближайшем тике."""
        self._stop_flag = True

    async def sync_now(self) -> Optional[SyncResult]:
        """Синк по текущим настройкам (pull_on_tick). Работает даже если авто-синк выключен."""
        return await self._do_sync()

    async def sync_now_pull(self) -> Optional[SyncResult]:
        """Синк с принудительным pull (например, при входе или по кнопке)."""
        saved = self.pull_on_tick
        self.pull_on_tick = True
        try:
            return await self._do_sync()
        finally:
            self.pull_on_tick = saved

    async def _run(self):
        # Быстрый первый тик: приложение уже синкнулось при логине, просто
        # даём UI догрузиться.
        await asyncio.sleep(5)

        while not self._stop_flag:
            enabled = _get_sync_enabled(self.db)
            interval = _get_sync_interval(self.db, self.interval)
            if interval != self.interval:
                self.interval = interval
                print(f"[sync_loop] interval updated to {interval}s")

            if enabled:
                try:
                    await self._do_sync()
                except Exception as e:
                    self._safe_error(e)
            else:
                print("[sync_loop] auto-sync disabled, skip tick")

            # Разбиваем sleep на чанки, чтобы реагировать на смену настроек
            # без перезапуска приложения.
            sleep_total = interval if enabled else 60
            slept = 0
            while slept < sleep_total and not self._stop_flag:
                chunk = min(SLEEP_CHUNK, sleep_total - slept)
                await asyncio.sleep(chunk)
                slept += chunk
                # Прерываем если настройки изменились
                new_enabled = _get_sync_enabled(self.db)
                new_interval = _get_sync_interval(self.db, interval)
                if new_enabled != enabled or new_interval != interval:
                    print("[sync_loop] settings changed, wake up")
                    break

    async def _do_sync(self) -> Optional[SyncResult]:
        async with self._get_lock():
            return await self._do_sync_unlocked()

    async def _do_sync_unlocked(self) -> Optional[SyncResult]:
        if not self.session.is_authenticated:
            return None

        try:
            token = self.session.ensure_fresh_token()
        except Exception as e:
            self._safe_error(e)
            return None

        fs = FirestoreClient(token)
        uid = self.session.uid
        do_pull = self.pull_on_tick

        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            lambda: sync_once(self.db, fs, uid, do_pull=do_pull),
        )

        if result.skipped_no_network:
            invalidate_network_cache()

        if self.on_result:
            try:
                self.on_result(result)
            except Exception as e:
                self._safe_error(e)

        return result

    def _safe_error(self, e: Exception):
        if self.on_error:
            try:
                self.on_error(e)
            except Exception:
                pass