# sync/network_cache.py
import time
import requests

_last_network_check = 0
_last_network_result = True
NETWORK_CACHE_TTL = 10  # секунд

PROBE_URL = "https://firestore.googleapis.com/"
PROBE_TIMEOUT = 3


def _real_check() -> bool:
    try:
        # 404/403/200 — не важно, главное что TCP+TLS установились
        requests.head(PROBE_URL, timeout=PROBE_TIMEOUT)
        return True
    except requests.RequestException:
        return False


def cached_network_available() -> bool:
    global _last_network_check, _last_network_result
    now = time.time()
    if now - _last_network_check > NETWORK_CACHE_TTL:
        _last_network_result = _real_check()
        _last_network_check = now
    return _last_network_result


def invalidate_network_cache():
    global _last_network_check
    _last_network_check = 0