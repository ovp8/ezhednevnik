# recurrence.py
"""Вычисление следующей даты для задачи с repeat.

Поддерживаемые типы repeat:
  {"type": "hourly",  "interval": N}          → +N часов
  {"type": "daily",   "interval": N}          → +N дней
  {"type": "days",    "days": [0..6]}         → ближайший из списка (0=Пн)
  {"type": "monthly", "day": 1..31}           → следующее N-е число месяца
  {"type": "yearly",  "month": 1..12, "day": 1..31}  → следующий год, тот же месяц/день
"""
import calendar
from datetime import datetime, timedelta
from typing import Optional


def _parse_task_datetime(task: dict) -> Optional[datetime]:
    dt_str = task.get("datetime") or ""
    if " " not in dt_str:
        return None
    try:
        return datetime.strptime(dt_str.strip(), "%Y-%m-%d %H:%M")
    except Exception:
        return None


def next_occurrence_datetime(task: dict) -> Optional[datetime]:
    """
    Возвращает datetime следующего срабатывания задачи
    или None, если repeat отсутствует / невалиден.
    """
    repeat = task.get("repeat")
    if not isinstance(repeat, dict):
        return None

    rtype = repeat.get("type")
    cur = _parse_task_datetime(task)
    if cur is None:
        return None

    # ----- hourly -----
    if rtype == "hourly":
        try:
            n = max(1, int(repeat.get("interval", 1) or 1))
        except Exception:
            n = 1
        return cur + timedelta(hours=n)

    # ----- daily -----
    if rtype == "daily":
        try:
            n = max(1, int(repeat.get("interval", 1) or 1))
        except Exception:
            n = 1
        return cur + timedelta(days=n)

    # ----- days (по дням недели, 0=Пн) -----
    if rtype == "days":
        days = repeat.get("days") or []
        try:
            days = [int(d) for d in days]
        except Exception:
            days = []
        days = [d for d in days if 0 <= d <= 6]
        if not days:
            return None
        for i in range(1, 15):
            cand = cur + timedelta(days=i)
            if cand.weekday() in days:
                return cand
        return None

    # ----- monthly -----
    if rtype == "monthly":
        try:
            day = int(repeat.get("day", 1) or 1)
        except Exception:
            day = 1
        day = max(1, min(31, day))

        y, m = cur.year, cur.month
        # следующий месяц
        if m == 12:
            m = 1
            y += 1
        else:
            m += 1

        last_day = calendar.monthrange(y, m)[1]
        real_day = min(day, last_day)
        try:
            return cur.replace(year=y, month=m, day=real_day)
        except Exception:
            return None

    # ----- yearly -----
    if rtype == "yearly":
        try:
            month = int(repeat.get("month", 1) or 1)
            day = int(repeat.get("day", 1) or 1)
        except Exception:
            month, day = 1, 1
        month = max(1, min(12, month))
        day = max(1, min(31, day))

        y = cur.year + 1
        last_day = calendar.monthrange(y, month)[1]
        real_day = min(day, last_day)
        try:
            return cur.replace(year=y, month=month, day=real_day)
        except Exception:
            return None

    return None


def format_repeat_human(repeat) -> str:
    """Краткое человекочитаемое описание повтора."""
    if not isinstance(repeat, dict):
        return ""
    rtype = repeat.get("type")
    if rtype == "hourly":
        n = repeat.get("interval", 1) or 1
        return "🔁 Ежечасно" if n == 1 else f"🔁 Каждые {n} ч."
    if rtype == "daily":
        n = repeat.get("interval", 1) or 1
        return "🔁 Ежедневно" if n == 1 else f"🔁 Каждые {n} дн."
    if rtype == "days":
        names = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
        try:
            days = sorted(int(d) for d in (repeat.get("days") or []) if 0 <= int(d) <= 6)
        except Exception:
            days = []
        if not days:
            return ""
        return "🔁 " + ", ".join(names[d] for d in days)
    if rtype == "monthly":
        return f"🔁 {repeat.get('day', 1)}-го числа"
    if rtype == "yearly":
        months = ["янв", "фев", "мар", "апр", "мая", "июн",
                  "июл", "авг", "сен", "окт", "ноя", "дек"]
        m = int(repeat.get("month", 1) or 1)
        d = int(repeat.get("day", 1) or 1)
        m = max(1, min(12, m))
        return f"🔁 {d} {months[m-1]}"
    return ""