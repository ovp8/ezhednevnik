# iphone_server.py
"""HTTP-сервер «Ежедневника» для iPhone (PWA) и любых браузеров.

Что делает:
  1. Поднимает Flet web-приложение (тот же main.py, что и на Android) через
     flet_web/fastapi + uvicorn.
  2. Отдаёт PWA-ассеты из ./assets (index.html, manifest.json, иконки, sw.js) —
     это позволяет установить приложение на iPhone через Safari:
     «Поделиться» -> «На экран „Домой“» — без App Store, iCloud и Apple ID.
  3. Предоставляет /api/push/* — Web Push (VAPID): подписки браузера,
     публичный ключ, тестовая отправка. Напоминания уходят на iPhone даже
     когда PWA закрыта (iOS 16.4+).

Запуск (из каталога project):
    python iphone_server.py                     # 0.0.0.0:8561
    PORT=8600 python iphone_server.py           # свой порт
    HOST=127.0.0.1 PORT=8561 python iphone_server.py

HTTPS (обязателен для Web Push и установки PWA):
    - локально: за Cloudflare Tunnel / caddy / nginx + Let's Encrypt
    - см. docs/Руководство_установка_на_iPhone
"""
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
os.chdir(BASE_DIR)

# Каталог данных (БД, auth_session.json, webpush_*.json).
# По умолчанию — каталог проекта; переопределяется переменной окружения.
os.environ.setdefault("FLET_APP_STORAGE_DATA", BASE_DIR)
os.makedirs(os.environ["FLET_APP_STORAGE_DATA"], exist_ok=True)

import logging
import socket

import uvicorn

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("iphone_server")

# --- Перехват логов: буфер последних строк + фильтр health-спама ---
# Включаем ДО импорта flet/uvicorn, чтобы поймать весь последующий вывод.
import log_capture  # noqa: E402

log_capture.setup()

# Пароль для страницы /logs. Можно поменять: LOG_TOKEN=xxx в окружении
# (на Render: Dashboard -> сервис -> Environment -> Add Environment Variable).
LOG_TOKEN = os.getenv("LOG_TOKEN", "ezhednevnik")


# ---------------- Flet-приложение ----------------

from main import main as flet_main, DB_PATH  # noqa: E402 (после установки env)

from flet_web.fastapi import app as build_flet_app  # noqa: E402
from flet.controls.types import WebRenderer  # noqa: E402

ASSETS_DIR = os.path.join(BASE_DIR, "assets")

app = build_flet_app(
    flet_main,
    assets_dir=ASSETS_DIR,
    app_name="Ежедневник",
    app_short_name="Ежедневник",
    app_description="Задачи, напоминания, синхронизация. Работает офлайн.",
    web_renderer=WebRenderer.AUTO,
)


# ---------------- API: Web Push ----------------

from fastapi import Request  # noqa: E402
from fastapi.responses import JSONResponse  # noqa: E402

from notifications import web_push  # noqa: E402

_api_routes = []


@app.post("/api/push/subscribe")
async def api_push_subscribe(request: Request):
    """Сохраняет подписку браузера: {uid, timezone?, subscription{endpoint,keys}}."""
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "error": "invalid json"}, status_code=400)

    subscription = data.get("subscription") or {}
    endpoint = subscription.get("endpoint")
    if not endpoint or not (subscription.get("keys") or {}):
        return JSONResponse({"ok": False, "error": "subscription endpoint/keys required"},
                            status_code=400)

    uid = (data.get("uid") or "").strip()
    added = web_push.add_subscription(uid, subscription)

    # Часовой пояс устройства пользователя (для расчёта времени напоминаний)
    tz = (data.get("timezone") or "").strip()
    tz_saved = False
    if tz:
        tz_saved = _save_user_timezone(tz)

    return {"ok": True, "added": added, "timezone_saved": tz_saved}


@app.post("/api/push/unsubscribe")
async def api_push_unsubscribe(request: Request):
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "error": "invalid json"}, status_code=400)
    removed = web_push.remove_subscription(data.get("endpoint") or "")
    return {"ok": True, "removed": removed}


@app.get("/api/push/vapid_public_key")
async def api_vapid_public_key():
    try:
        return {"publicKey": web_push.get_vapid_public_key()}
    except Exception as ex:
        return JSONResponse({"error": str(ex)}, status_code=500)


@app.post("/api/push/report_tz")
async def api_report_tz(request: Request):
    """Часовой пояс устройства: {timezone: 'Europe/Moscow'}."""
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "error": "invalid json"}, status_code=400)
    ok = _save_user_timezone((data.get("timezone") or "").strip())
    return {"ok": ok}


@app.post("/api/push/test")
async def api_push_test(request: Request):
    """Тестовая отправка: {uid?, title?, body?}. Пустой uid — непривязанным подпискам."""
    try:
        data = await request.json()
    except Exception:
        data = {}
    uid = (data.get("uid") or "").strip()
    title = data.get("title") or "Ежедневник"
    body = data.get("body") or "Тестовое уведомление — если вы это видите, всё работает ✓"
    result = web_push.send_to_uid(uid, title, body, {"task_id": 0})
    return {"ok": True, **result}


@app.get("/api/health")
async def api_health():
    return {"status": "ok", "app": "Ежедневник", "db": os.path.exists(DB_PATH)}


@app.get("/favicon.ico")
async def favicon_ico():
    """Браузеры сами запрашивают /favicon.ico — отдаём наш favicon.png,
    иначе в логах постоянно висит 404."""
    from fastapi.responses import FileResponse
    return FileResponse(
        os.path.join(ASSETS_DIR, "favicon.png"), media_type="image/png",
    )


# ---------------- API / UI: просмотр логов ----------------

@app.get("/api/logs")
async def api_logs(request: Request, token: str = "", limit: int = 500,
                   q: str = "", format: str = "json", clear: int = 0):
    """Последние строки лога сервера. Пример: /api/logs?token=...&limit=1000.

    format=txt — отдать как файл (для скачивания); clear=1 — очистить буфер.
    """
    if token != LOG_TOKEN:
        return JSONResponse({"error": "invalid token"}, status_code=403)
    if clear:
        log_capture.clear()
    limit = max(1, min(limit, log_capture.CAPACITY))
    lines = log_capture.recent(limit=limit, contains=q)
    if format == "txt":
        from fastapi.responses import PlainTextResponse
        return PlainTextResponse(
            "\n".join(lines) + "\n",
            headers={"Content-Disposition": 'attachment; filename="ezhednevnik-logs.txt"'},
        )
    return {"ok": True, **log_capture.stats(), "lines": lines}


_LOGS_HTML = """<!doctype html>
<html lang="ru"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ежедневник · Логи</title>
<style>
:root{color-scheme:dark}
body{margin:0;background:#0d1117;color:#c9d1d9;
  font:13px/1.45 ui-monospace,SFMono-Regular,Consolas,Menlo,monospace}
#bar{position:sticky;top:0;z-index:9;display:flex;gap:8px;align-items:center;
  flex-wrap:wrap;padding:8px 12px;background:#161b22;border-bottom:1px solid #30363d}
#bar .t{font-weight:600;color:#e6edf3;margin-right:auto;font-family:system-ui,Segoe UI,sans-serif}
input,select,button,a.btn{background:#0d1117;color:#c9d1d9;border:1px solid #30363d;
  border-radius:6px;padding:4px 8px;font:inherit}
button{cursor:pointer}a{text-decoration:none}
#out{padding:10px 12px;white-space:pre-wrap;word-break:break-all}
.err{color:#ff7b72}.warn{color:#d29922}.ok{color:#3fb950}.dim{color:#8b949e}
#meta{color:#8b949e;font-size:11px;width:100%}
</style></head><body>
<div id="bar">
  <span class="t">Ежедневник · логи сервера</span>
  <button id="refresh">Обновить</button>
  <button id="pause">Пауза</button>
  <button id="clear">Очистить</button>
  <a class="btn" id="dl" download href="#">Скачать .txt</a>
  <select id="limit">
    <option>200</option><option selected>500</option>
    <option>1000</option><option>2000</option>
  </select>
  <input id="q" placeholder="фильтр по тексту..." size="18">
  <span id="meta"></span>
</div>
<pre id="out">загрузка…</pre>
<script>
const $ = id => document.getElementById(id);
const TOKEN = new URLSearchParams(location.search).get('token') || '';
let paused = false, busy = false;
const api = extra => `/api/logs?token=${encodeURIComponent(TOKEN)}${extra || ''}`;
const esc = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
async function refresh(){
  if (busy) return; busy = true;
  try {
    const r = await fetch(api('&limit=' + $('limit').value));
    if (r.status === 403) {
      const t = prompt('Введите token для просмотра логов:');
      if (t) { location.search = '?token=' + encodeURIComponent(t); return; }
      $('out').textContent = 'Нужен token: откройте адрес /logs?token=...';
      return;
    }
    const j = await r.json();
    let lines = j.lines || [];
    const q = $('q').value.trim().toLowerCase();
    if (q) lines = lines.filter(l => l.toLowerCase().includes(q));
    const atBottom = window.innerHeight + window.scrollY >= document.body.offsetHeight - 80;
    $('out').innerHTML = lines.map(l => {
      let c = '';
      if (/ERROR|CRITICAL|Traceback/i.test(l)) c = 'err';
      else if (/WARNING|WARN/i.test(l)) c = 'warn';
      else if (/WebSocket.*accepted|Application startup complete/i.test(l)) c = 'ok';
      return '<div class="' + c + '">' + esc(l) + '<' + '/div>';
    }).join('') || '<div class="dim">— пусто —</div>';
    $('meta').textContent = 'в буфере: ' + j.total + ' строк · скрыто health-проверок: '
      + j.dropped_health + ' · аптайм: ' + Math.floor(j.uptime_sec / 60) + ' мин';
    $('dl').href = api('&limit=2000&format=txt');
    if (atBottom && !paused) window.scrollTo(0, document.body.scrollHeight);
  } catch (e) {
    $('meta').textContent = 'ошибка сети: ' + e;
  } finally { busy = false; }
}
$('refresh').onclick = refresh;
$('pause').onclick = () => { paused = !paused; $('pause').textContent = paused ? 'Продолжить' : 'Пауза'; };
$('clear').onclick = async () => {
  if (confirm('Очистить буфер логов?')) { await fetch(api('&clear=1')); refresh(); }
};
setInterval(() => { if (!paused) refresh(); }, 3000);
refresh();
</script>
</body></html>"""


@app.get("/logs")
async def logs_page():
    """Страница просмотра логов: /logs?token=... (автообновление, поиск, скачивание)."""
    from fastapi.responses import HTMLResponse
    return HTMLResponse(_LOGS_HTML)


# регистрируем API-маршруты ПЕРЕД mount("/") статических файлов
_api_paths = {
    "/api/push/subscribe", "/api/push/unsubscribe", "/api/push/vapid_public_key",
    "/api/push/report_tz", "/api/push/test", "/api/health",
    "/api/logs", "/logs", "/favicon.ico",
}
app.router.routes = (
    [r for r in app.router.routes if getattr(r, "path", "") in _api_paths]
    + [r for r in app.router.routes if getattr(r, "path", "") not in _api_paths]
)


# ---------------- Часовой пояс пользователя ----------------

_tz_db = None  # ленивый синглтон LocalDB для API


def _save_user_timezone(tz_name: str) -> bool:
    """Сохраняет настройку user_timezone в БД (используется repo при расчёте напоминаний)."""
    if not tz_name:
        return False
    global _tz_db
    try:
        from zoneinfo import ZoneInfo
        ZoneInfo(tz_name)  # валидация
    except Exception as ex:
        logger.warning("invalid timezone %r: %s", tz_name, ex)
        return False
    try:
        if _tz_db is None:
            from db.local_db import LocalDB
            _tz_db = LocalDB(DB_PATH)
            _tz_db.init_schema()
        _tz_db.set_setting("user_timezone", tz_name)
        logger.info("user_timezone saved: %s", tz_name)
        return True
    except Exception as ex:
        logger.warning("save timezone error: %s", ex)
        return False


# ---------------- Запуск ----------------

def _lan_ips() -> list:
    import re
    ip_re = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")
    ips = []

    def _ok(ip):
        return ip and ip_re.match(ip) and not ip.startswith("127.") \
            and ip not in ips

    try:
        host, _, _ = socket.gethostbyname_ex(socket.gethostname())
        for ip in host:
            if _ok(ip):
                ips.append(ip)
    except Exception:
        pass
    if not ips:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            if _ok(ip):
                ips.append(ip)
        except Exception:
            pass
    return ips


if __name__ == "__main__":
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", os.getenv("FLET_SERVER_PORT", "8561")))

    print("=" * 62)
    print("  Ежедневник — сервер для iPhone (PWA)")
    print("=" * 62)
    print(f"  Локально:   http://127.0.0.1:{port}")
    for ip in _lan_ips():
        print(f"  В сети Wi-Fi: http://{ip}:{port}   <- открывать в Safari на iPhone")
    print("  Для Web Push и установки на iPhone нужен HTTPS")
    print("  (Cloudflare Tunnel / VPS / обратный прокси — см. руководство).")
    print(f"  Логи сервера: http://127.0.0.1:{port}/logs?token={LOG_TOKEN}")
    print("  (на Render открывайте https://<ваш-адрес>.onrender.com/logs?token=...)")
    print("=" * 62)

    uvicorn.run(app, host=host, port=port, log_level="info")
