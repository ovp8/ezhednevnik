# notifications/storage.py
"""Хранение напоминаний в SQLite.

Каждая строка — запланированное событие. Роли (kind):
  * 'before'  — предупредить заранее (minutes_before > 0)
  * 'at_time' — в момент события (minutes_before = 0)
  * 'repeat'  — автоповтор невыполненной задачи

Параметры повтора (repeat_interval_min, repeat_max, repeat_count)
живут в самой строке. У 'before'/'at_time' они задают «родительский»
лимит. У 'repeat' — счётчик, который инкрементится при каждом срабатывании.
"""
from datetime import datetime, timezone, timedelta
from db.local_db import LocalDB


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _iso_after(seconds: int = 0) -> str:
    dt = datetime.now(timezone.utc) + timedelta(seconds=seconds)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


class ReminderStorage:
    def __init__(self, db: LocalDB):
        self.db = db

    # ---------------- Запись ----------------

    def add(self, task_id: int, task_text: str, fire_at: str,
            minutes_before: int = 15) -> int:
        """Старый API — оставлен для совместимости (kind='before')."""
        return self.add_full(
            task_id=task_id, task_text=task_text, fire_at=fire_at,
            minutes_before=minutes_before, kind="before",
            repeat_interval_min=0, repeat_max=0, repeat_count=0,
        )

    def add_full(self, task_id: int, task_text: str, fire_at: str,
                 minutes_before: int, kind: str,
                 repeat_interval_min: int = 0,
                 repeat_max: int = 0,
                 repeat_count: int = 0) -> int:
        with self.db._lock:
            cur = self.db.conn.execute(
                """INSERT INTO reminders
                   (task_id, task_text, fire_at, minutes_before,
                    fired, created_at,
                    kind, repeat_interval_min, repeat_max, repeat_count)
                   VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?)""",
                (task_id, task_text, fire_at, minutes_before,
                 _now_iso(), kind,
                 repeat_interval_min, repeat_max, repeat_count),
            )
            self.db.conn.commit()
            return cur.lastrowid

    def add_repeat(self, task_id: int, task_text: str,
                   interval_min: int, repeat_max: int, repeat_count: int) -> int:
        """Создаёт дочернюю запись повтора через interval_min минут."""
        fire_at = _iso_after(interval_min * 60)
        return self.add_full(
            task_id=task_id, task_text=task_text,
            fire_at=fire_at, minutes_before=0,
            kind="repeat",
            repeat_interval_min=interval_min,
            repeat_max=repeat_max,
            repeat_count=repeat_count,
        )

    def delete_for_task(self, task_id: int):
        with self.db._lock:
            self.db.conn.execute("DELETE FROM reminders WHERE task_id = ?",
                                 (task_id,))
            self.db.conn.commit()

    # ---------------- Чтение ----------------

    def get_for_task(self, task_id: int) -> list:
        with self.db._lock:
            cur = self.db.conn.execute(
                "SELECT * FROM reminders WHERE task_id = ? ORDER BY fire_at ASC",
                (task_id,),
            )
            return [dict(r) for r in cur.fetchall()]

    def get_config(self, task_id: int) -> dict:
        """Возвращает конфиг напоминания задачи (для формы /reminders)."""
        rows = self.get_for_task(task_id)
        cfg = {
            "before": None,          # int или None
            "at_time": False,        # bool
            "repeat": False,         # bool
            "repeat_interval": 5,    # int
            "repeat_max": 4,         # int
        }
        for r in rows:
            kind = r.get("kind") or "before"
            if kind == "before":
                cfg["before"] = int(r.get("minutes_before") or 0)
                if int(r.get("repeat_interval_min") or 0) > 0:
                    cfg["repeat"] = True
                    cfg["repeat_interval"] = int(r.get("repeat_interval_min") or 5)
                    cfg["repeat_max"] = int(r.get("repeat_max") or 4)
            elif kind == "at_time":
                cfg["at_time"] = True
                if int(r.get("repeat_interval_min") or 0) > 0:
                    cfg["repeat"] = True
                    cfg["repeat_interval"] = int(r.get("repeat_interval_min") or 5)
                    cfg["repeat_max"] = int(r.get("repeat_max") or 4)
        return cfg

    def get_due(self, now_iso: str) -> list:
        with self.db._lock:
            cur = self.db.conn.execute(
                """SELECT * FROM reminders
                   WHERE fired = 0 AND fire_at <= ?
                   ORDER BY fire_at ASC""",
                (now_iso,),
            )
            return [dict(r) for r in cur.fetchall()]

    def mark_fired(self, reminder_id: int):
        with self.db._lock:
            self.db.conn.execute(
                "UPDATE reminders SET fired = 1, fired_at = ? WHERE id = ?",
                (_now_iso(), reminder_id),
            )
            self.db.conn.commit()

    def clear_old(self, before_iso: str) -> int:
        with self.db._lock:
            cur = self.db.conn.execute(
                "SELECT COUNT(*) as c FROM reminders WHERE fired = 1 AND fired_at < ?",
                (before_iso,),
            )
            n = cur.fetchone()["c"]
            self.db.conn.execute(
                "DELETE FROM reminders WHERE fired = 1 AND fired_at < ?",
                (before_iso,),
            )
            self.db.conn.commit()
            return n

    def clear_all(self) -> int:
        """Удаляет ВСЕ напоминания (fired и pending)."""
        with self.db._lock:
            cur = self.db.conn.execute("SELECT COUNT(*) as c FROM reminders")
            n = cur.fetchone()["c"]
            self.db.conn.execute("DELETE FROM reminders")
            self.db.conn.commit()
            return n

    def clear_pending(self) -> int:
        """Удаляет только несработавшие (fired=0)."""
        with self.db._lock:
            cur = self.db.conn.execute(
                "SELECT COUNT(*) as c FROM reminders WHERE fired = 0")
            n = cur.fetchone()["c"]
            self.db.conn.execute("DELETE FROM reminders WHERE fired = 0")
            self.db.conn.commit()
            return n

    def clear_fired_before(self, before_date: str) -> int:
        """Удаляет сработавшие (fired=1) с fired_at < before_date."""
        with self.db._lock:
            bound = f"{before_date}"
            cur = self.db.conn.execute(
                "SELECT COUNT(*) as c FROM reminders WHERE fired = 1 AND fired_at < ?",
                (bound,))
            n = cur.fetchone()["c"]
            self.db.conn.execute(
                "DELETE FROM reminders WHERE fired = 1 AND fired_at < ?",
                (bound,))
            self.db.conn.commit()
            return n