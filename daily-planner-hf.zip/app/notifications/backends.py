# notifications/backends.py
"""Backend'ы доставки уведомлений.

  - AsyncioBackend — заглушка: печатает в консоль (десктоп и тесты).
  - AndroidBackend — триггерит native-код (ReminderReceiver.kt) через broadcast.
    Сам NOTIFICATION НЕ показывает — Kotlin отвечает за канал, actions, звук.
  - WebBackend — браузер / iPhone-PWA: in-app callback + Web Push (VAPID).
    Push доставляется сервером через notifications/web_push.py даже когда
    PWA закрыта (iOS 16.4+). Разрешение и подписка оформляются на странице
    /push-setup.html (открывается из Настроек).
"""
import asyncio
import os
import sys
import logging
from typing import Optional, Callable
from datetime import datetime

logger = logging.getLogger(__name__)

_RECEIVER_CLASS = "com.flet.dailyplanner.ReminderReceiver"
_ACTION_SHOW = "com.flet.dailyplanner.SHOW_REMINDER"


def _is_android() -> bool:
    env_markers = ("ANDROID_STORAGE", "ANDROID_ARGUMENT", "ANDROID_PRIVATE",
                   "ANDROID_APP_PATH", "P4A_BOOTSTRAP")
    for m in env_markers:
        if os.environ.get(m):
            return True
    return "android" in sys.platform.lower()


class BaseBackend:
    def __init__(self, on_show: Optional[Callable] = None):
        self.on_show = on_show
        self._permission_ok = False

    async def request_permissions(self) -> bool:
        return True

    async def show(self, title: str, body: str, extra: dict = None) -> None:
        raise NotImplementedError

    async def _call_ui_callback(self, title, body, extra):
        if not self.on_show:
            return
        try:
            result = self.on_show(title, body, extra)
            if asyncio.iscoroutine(result):
                await result
        except Exception as ex:
            logger.warning("[notify] on_show error: %s", ex)


class AsyncioBackend(BaseBackend):
    async def show(self, title: str, body: str, extra: dict = None) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        print(f"[NOTIFY {ts}] {title} — {body}")
        await self._call_ui_callback(title, body, extra or {})


class AndroidBackend(BaseBackend):
    """Триггерит Kotlin-код (ReminderReceiver.kt) через broadcast.

    ВСЕ extras передаём как String через Bundle — обходит коллизию overload'ов
    putExtra(String,int) в jnius.
    """

    def __init__(self, on_show: Optional[Callable] = None):
        super().__init__(on_show)
        self._context = None
        self._init_error = None
        self._init_android()

    def _init_android(self):
        try:
            from jnius import autoclass
            ActivityThread = autoclass("android.app.ActivityThread")
            app = ActivityThread.currentApplication()
            if app is None:
                self._init_error = "ActivityThread.currentApplication() → None"
                print(f"[notify] init: {self._init_error}")
                return
            self._context = app.getApplicationContext()
            print("[notify] android context OK (broadcast mode)")
        except Exception as ex:
            self._init_error = str(ex)
            print(f"[notify] init error: {ex}")

    async def request_permissions(self) -> bool:
        if self._context is None:
            return False
        try:
            from jnius import autoclass
            Context = autoclass("android.content.Context")
            manager = self._context.getSystemService(Context.NOTIFICATION_SERVICE)
            if manager is None:
                return False
            enabled = bool(manager.areNotificationsEnabled())
            self._permission_ok = enabled
            print(f"[notify] notifications enabled: {enabled}")
            return enabled
        except Exception as ex:
            print(f"[notify] areNotificationsEnabled fail: {ex}")
            return False

    async def show(self, title: str, body: str, extra: dict = None) -> None:
        extra = extra or {}

        if self._context is None:
            print("[notify] no context — fallback to asyncio")
            await self._call_ui_callback(title, body, extra)
            return

        try:
            task_id = int(extra.get("task_id", 0) or 0)
            if not task_id:
                task_id = int(extra.get("id", 0) or 0)

            self._send_native_trigger(task_id, title, body)
            print(f"[notify] sent broadcast task_id={task_id}: {title} — {body}")
        except Exception as ex:
            print(f"[notify] broadcast fail: {ex}")

        await self._call_ui_callback(title, body, extra)

    def _send_native_trigger(self, task_id: int, title: str, body: str):
        """Шлёт broadcast в ReminderReceiver.kt через Bundle."""
        from jnius import autoclass

        Intent = autoclass("android.content.Intent")
        Bundle = autoclass("android.os.Bundle")
        JavaString = autoclass("java.lang.String")

        bundle = Bundle()
        bundle.putString(JavaString("title"), JavaString(str(title)))
        bundle.putString(JavaString("body"), JavaString(str(body)))
        bundle.putString(JavaString("notificationId"), JavaString(str(int(task_id))))

        intent = Intent()
        intent.setClassName(
            JavaString(str(self._context.getPackageName())),
            JavaString(_RECEIVER_CLASS),
        )
        intent.setAction(JavaString(_ACTION_SHOW))
        intent.putExtras(bundle)

        self._context.sendBroadcast(intent)


class WebBackend(BaseBackend):
    """Уведомления в браузере/PWA: in-app callback + Web Push через сервер."""

    def __init__(self, on_show: Optional[Callable] = None,
                 uid_provider: Optional[Callable] = None):
        super().__init__(on_show)
        self.uid_provider = uid_provider
        print("[notify] using WebBackend (in-app + Web Push)")

    def _uid(self) -> Optional[str]:
        try:
            return self.uid_provider() if self.uid_provider else None
        except Exception as ex:
            logger.warning("[notify] uid_provider error: %s", ex)
            return None

    async def request_permissions(self) -> bool:
        """Браузер спрашивает разрешение сам (push-setup.html).
        Здесь считаем OK, если есть хотя бы одна подписка либо push-стек не поднят."""
        try:
            from notifications import web_push
            return web_push.count_subscriptions(self._uid() or "") > 0
        except Exception:
            # pywebpush не установлен / нет хранилища — не блокируем вход
            return True

    async def show(self, title: str, body: str, extra: dict = None) -> None:
        extra = extra or {}

        # 1) in-app баннер (SnackBar) — работает в любой браузерной сессии
        await self._call_ui_callback(title, body, extra)

        # 2) системные уведомления через Web Push (iPhone-PWA, десктоп-браузеры)
        try:
            from notifications import web_push
            uid = self._uid() or ""
            web_push.send_to_uid(uid, title, body, extra)
        except Exception as ex:
            logger.warning("[notify] web push fail: %s", ex)


def get_default_backend(on_show: Optional[Callable] = None,
                       page=None,
                       uid_provider: Optional[Callable] = None) -> BaseBackend:
    """Выбирает бэкенд по платформе.

    :param page: flet.Page — если передан и page.web, используется WebBackend
                 (браузер / iPhone-PWA).
    :param uid_provider: callable -> uid Firebase (для привязки push-подписок).
    """
    if page is not None and getattr(page, "web", False):
        return WebBackend(on_show, uid_provider)
    if _is_android():
        print("[notify] using AndroidBackend (broadcast → ReminderReceiver.kt)")
        return AndroidBackend(on_show)
    print("[notify] using AsyncioBackend (desktop)")
    return AsyncioBackend(on_show)
