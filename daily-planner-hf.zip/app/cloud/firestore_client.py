# cloud/firestore_client.py
import time
import requests
from config import FIRESTORE_BASE


class FirestoreError(Exception):
    pass


# ---------- Конвертеры Python <-> Firestore ----------

def py_to_fs(value):
    if value is None:
        return {"nullValue": None}
    if isinstance(value, bool):
        return {"booleanValue": value}
    if isinstance(value, int):
        return {"integerValue": str(value)}
    if isinstance(value, float):
        return {"doubleValue": value}
    if isinstance(value, str):
        return {"stringValue": value}
    if isinstance(value, list):
        return {"arrayValue": {"values": [py_to_fs(v) for v in value]}}
    if isinstance(value, dict):
        return {"mapValue": {"fields": {k: py_to_fs(v) for k, v in value.items()}}}
    raise FirestoreError(f"Неподдерживаемый тип: {type(value)}")


def fs_to_py(fs_value):
    if "nullValue" in fs_value:
        return None
    if "booleanValue" in fs_value:
        return fs_value["booleanValue"]
    if "integerValue" in fs_value:
        return int(fs_value["integerValue"])
    if "doubleValue" in fs_value:
        return float(fs_value["doubleValue"])
    if "stringValue" in fs_value:
        return fs_value["stringValue"]
    if "timestampValue" in fs_value:
        return fs_value["timestampValue"]
    if "arrayValue" in fs_value:
        return [fs_to_py(v) for v in fs_value["arrayValue"].get("values", [])]
    if "mapValue" in fs_value:
        fields = fs_value["mapValue"].get("fields", {})
        return {k: fs_to_py(v) for k, v in fields.items()}
    return None


def dict_to_fs_fields(data: dict) -> dict:
    return {k: py_to_fs(v) for k, v in data.items()}


def fs_doc_to_py(doc: dict) -> dict:
    fields = doc.get("fields", {})
    result = {k: fs_to_py(v) for k, v in fields.items()}
    name = doc.get("name", "")
    result["_id"] = name.split("/")[-1] if name else None
    return result


# ---------- Клиент ----------

class FirestoreClient:
    def __init__(self, id_token: str):
        self.id_token = id_token
        self.headers = {"Authorization": f"Bearer {id_token}"}

    def _raise(self, resp: requests.Response):
        try:
            data = resp.json()
            err = data.get("error", {})
            message = err.get("message", resp.text)
            status = err.get("status", "")
            raise FirestoreError(f"{status} {message}".strip())
        except FirestoreError:
            raise
        except Exception:
            raise FirestoreError(f"HTTP {resp.status_code}: {resp.text[:200]}")

    # ---------- CRUD ----------

    def create_document(self, collection: str, data: dict) -> dict:
        url = f"{FIRESTORE_BASE}/{collection}"
        body = {"fields": dict_to_fs_fields(data)}
        resp = requests.post(url, headers=self.headers, json=body, timeout=15)
        if resp.status_code != 200:
            self._raise(resp)
        return fs_doc_to_py(resp.json())

    def set_document(self, collection: str, doc_id: str, data: dict) -> dict:
        url = f"{FIRESTORE_BASE}/{collection}/{doc_id}"
        body = {"fields": dict_to_fs_fields(data)}
        resp = requests.patch(url, headers=self.headers, json=body, timeout=15)
        if resp.status_code != 200:
            self._raise(resp)
        return fs_doc_to_py(resp.json())

    def get_document(self, collection: str, doc_id: str) -> dict:
        url = f"{FIRESTORE_BASE}/{collection}/{doc_id}"
        resp = requests.get(url, headers=self.headers, timeout=15)
        if resp.status_code != 200:
            self._raise(resp)
        return fs_doc_to_py(resp.json())

    def delete_document(self, collection: str, doc_id: str) -> None:
        """Жёсткое удаление документа. Используется, например, при очистке."""
        url = f"{FIRESTORE_BASE}/{collection}/{doc_id}"
        resp = requests.delete(url, headers=self.headers, timeout=15)
        if resp.status_code not in (200, 204):
            self._raise(resp)

    def soft_delete(self, collection: str, doc_id: str, user_id: str) -> dict:
        """
        Soft-delete: ставит deleted=true, обновляет updatedAt и userId.
        Документ остаётся в Firestore, но помечен как удалённый.
        Это позволяет мобильному увидеть факт удаления через delta-pull.
        """
        url = f"{FIRESTORE_BASE}/{collection}/{doc_id}"
        body = {
            "fields": dict_to_fs_fields({
                "deleted": True,
                "updatedAt": int(time.time() * 1000),
                "userId": user_id,
            })
        }
        # PATCH с маской — обновляем ТОЛЬКО эти поля, остальные не трогаем.
        params = {
            "updateMask.fieldPaths": ["deleted", "updatedAt", "userId"],
        }
        resp = requests.patch(url, headers=self.headers, json=body,
                              params=params, timeout=15)
        if resp.status_code != 200:
            self._raise(resp)
        return fs_doc_to_py(resp.json())

    # ---------- Query ----------

    def query(self, collection: str, filters: list, order_by: list = None,
              limit: int = 500) -> list:
        """
        Query с поддержкой EQUAL и range-операторов.

        filters: список кортежей
          - (field, value)                 → EQUAL
          - (field, op, value)             → EQUAL | GREATER_THAN | GREATER_THAN_OR_EQUAL
                                             | LESS_THAN | LESS_THAN_OR_EQUAL | NOT_EQUAL
        order_by: список кортежей (field, direction),
                  direction = "ASCENDING" | "DESCENDING"
        """
        field_filters = []
        for f in filters:
            if len(f) == 2:
                field, value = f
                op = "EQUAL"
            elif len(f) == 3:
                field, op, value = f
            else:
                raise FirestoreError(f"Некорректный фильтр: {f}")
            field_filters.append({
                "fieldFilter": {
                    "field": {"fieldPath": field},
                    "op": op,
                    "value": py_to_fs(value),
                }
            })

        structured_query = {
            "from": [{"collectionId": collection}],
            "where": {
                "compositeFilter": {
                    "op": "AND",
                    "filters": field_filters,
                }
            },
            "limit": limit,
        }

        if order_by:
            structured_query["orderBy"] = [
                {"field": {"fieldPath": f}, "direction": d}
                for f, d in order_by
            ]

        run_query_url = (
            f"https://firestore.googleapis.com/v1/projects/"
            f"{FIRESTORE_BASE.split('/projects/')[1].split('/databases')[0]}"
            f"/databases/(default)/documents:runQuery"
        )
        body = {"structuredQuery": structured_query}
        resp = requests.post(run_query_url, headers=self.headers,
                             json=body, timeout=20)
        if resp.status_code != 200:
            self._raise(resp)

        results = []
        for row in resp.json():
            if "document" in row:
                results.append(fs_doc_to_py(row["document"]))
        return results