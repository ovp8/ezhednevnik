# cloud/firebase_auth.py
import re
import time
import requests
from requests.exceptions import (
    ConnectionError as RequestsConnectionError,
    Timeout as RequestsTimeout,
    RequestException,
)
from config import (
    FIREBASE_API_KEY,
    AUTH_SIGN_UP_URL,
    AUTH_SIGN_IN_URL,
    AUTH_REFRESH_URL,
)


class FirebaseAuthError(Exception):
    """Ошибка Firebase Auth с человекочитаемым текстом."""
    def __init__(self, code: str, message: str):
        self.code = code
        self.message = message
        super().__init__(f"{code}: {message}")


ERROR_MESSAGES = {
    "EMAIL_EXISTS": "Этот email уже зарегистрирован",
    "EMAIL_NOT_FOUND": "Пользователь с таким email не найден",
    "INVALID_PASSWORD": "Неверный пароль",
    "INVALID_EMAIL": "Неверный формат email",
    "WEAK_PASSWORD": "Слишком слабый пароль (минимум 6 символов)",
    "MISSING_PASSWORD": "Пароль не указан",
    "USER_DISABLED": "Аккаунт отключен",
    "TOO_MANY_ATTEMPTS_TRY_LATER": "Слишком много попыток. Попробуйте позже",
    "INVALID_LOGIN_CREDENTIALS": "Неверный email или пароль",
    "OPERATION_NOT_ALLOWED": "Вход по Email/Password отключён в Firebase Console",
    "NETWORK_ERROR": "Нет подключения к интернету. Проверьте сеть и попробуйте снова.",
}


# ---- Валидация email (regex + блок-лист) ----

_EMAIL_REGEX = re.compile(
    r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$"
)

_BLOCKED_DOMAINS = {
    "test.com", "test.ru",
    "example.com", "example.org", "example.net",
    "localhost",
    "mailinator.com", "tempmail.com", "guerrillamail.com",
    "10minutemail.com", "yopmail.com", "trashmail.com",
    "throwaway.email", "fakeinbox.com", "sharklasers.com",
    "getnada.com", "dispostable.com", "mintemail.com",
}

_BLOCKED_TLDS = (".test", ".example", ".invalid", ".local")


def validate_email(email: str) -> None:
    """
    Проверяет email перед регистрацией.
    Бросает FirebaseAuthError("INVALID_EMAIL", ...) при проблемах.
    """
    email = (email or "").strip().lower()
    if not email:
        raise FirebaseAuthError("INVALID_EMAIL", "Введите email")
    if not _EMAIL_REGEX.match(email):
        raise FirebaseAuthError(
            "INVALID_EMAIL",
            "Неверный формат email (пример: name@mail.ru)"
        )
    domain = email.split("@", 1)[1]
    if domain in _BLOCKED_DOMAINS:
        raise FirebaseAuthError(
            "INVALID_EMAIL",
            "Этот домен не принимается. Используйте реальную почту."
        )
    for tld in _BLOCKED_TLDS:
        if domain.endswith(tld):
            raise FirebaseAuthError(
                "INVALID_EMAIL",
                "Используйте реальный email (не test/example)."
            )


def _parse_error(resp: requests.Response) -> FirebaseAuthError:
    try:
        data = resp.json()
        err = data.get("error", {}) or {}
        raw = err.get("message", "UNKNOWN")
        # Формат: "EMAIL_EXISTS" или "WEAK_PASSWORD : Password should be..."
        code = raw.split(":")[0].split(" ")[0].strip()
        message = ERROR_MESSAGES.get(code, raw)
        return FirebaseAuthError(code, message)
    except Exception:
        return FirebaseAuthError("UNKNOWN", f"HTTP {resp.status_code}: {resp.text[:200]}")


def _handle_network_error(ex: Exception) -> FirebaseAuthError:
    """Преобразует сетевые ошибки requests в понятный FirebaseAuthError."""
    print(f"[auth] network error: {type(ex).__name__}: {ex}")
    if isinstance(ex, (RequestsConnectionError, RequestsTimeout)):
        return FirebaseAuthError(
            "NETWORK_ERROR",
            "Нет подключения к интернету. Проверьте сеть и попробуйте снова."
        )
    if isinstance(ex, RequestException):
        return FirebaseAuthError(
            "NETWORK_ERROR",
            "Ошибка сети при попытке связаться с сервером."
        )
    return FirebaseAuthError(
        "UNKNOWN_ERROR",
        "Произошла неизвестная ошибка. Попробуйте позже."
    )


def sign_up(email: str, password: str) -> dict:
    """Регистрация. Возвращает dict с idToken, refreshToken, localId (UID), email."""
    validate_email(email)
    try:
        resp = requests.post(
            AUTH_SIGN_UP_URL,
            json={"email": email, "password": password, "returnSecureToken": True},
            timeout=15,
        )
    except Exception as ex:
        raise _handle_network_error(ex)

    if resp.status_code != 200:
        raise _parse_error(resp)
    return resp.json()


def sign_in(email: str, password: str) -> dict:
    """Вход. Возвращает dict с idToken, refreshToken, localId (UID), email."""
    try:
        resp = requests.post(
            AUTH_SIGN_IN_URL,
            json={"email": email, "password": password, "returnSecureToken": True},
            timeout=15,
        )
    except Exception as ex:
        raise _handle_network_error(ex)

    if resp.status_code != 200:
        raise _parse_error(resp)
    return resp.json()


def refresh_id_token(refresh_token: str) -> dict:
    """Обновление idToken по refreshToken (idToken живёт 1 час)."""
    try:
        resp = requests.post(
            AUTH_REFRESH_URL,
            data={"grant_type": "refresh_token", "refresh_token": refresh_token},
            timeout=15,
        )
    except Exception as ex:
        raise _handle_network_error(ex)

    if resp.status_code != 200:
        raise _parse_error(resp)
    data = resp.json()
    return {
        "idToken": data["id_token"],
        "refreshToken": data["refresh_token"],
        "localId": data["user_id"],
    }


def auth_result_to_session(result: dict) -> dict:
    """Преобразовать ответ sign_in/sign_up в формат auth_session.json."""
    return {
        "uid": result["localId"],
        "email": result["email"],
        "idToken": result["idToken"],
        "refreshToken": result["refreshToken"],
        "expiresAt": int(time.time()) + int(result["expiresIn"]),
    }


AUTH_OOB_URL = (
    "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode"
    f"?key={FIREBASE_API_KEY}"
)


def send_password_reset(email: str) -> None:
    """Отправить письмо для сброса пароля."""
    try:
        resp = requests.post(
            AUTH_OOB_URL,
            json={"requestType": "PASSWORD_RESET", "email": email},
            timeout=15,
        )
    except Exception as ex:
        raise _handle_network_error(ex)

    if resp.status_code != 200:
        raise _parse_error(resp)