# cloud/auth_storage.py
"""
Локальное хранилище сессии Firebase Auth.
Файл лежит рядом с БД приложения. Содержит idToken, refreshToken, uid, email.
"""
import os
import json
import time
from typing import Optional

def _auth_dir() -> str:
    env = os.getenv("FLET_APP_STORAGE_DATA")
    if env:
        return env
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


DEFAULT_AUTH_FILE = os.path.join(_auth_dir(), "auth_session.json")


def save_auth(data: dict, path: str = DEFAULT_AUTH_FILE) -> None:
    """
    data = {
        'uid': str, 'email': str, 'idToken': str, 'refreshToken': str,
        'expiresAt': int (unix seconds, момент истечения idToken)
    }
    """
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def load_auth(path: str = DEFAULT_AUTH_FILE) -> Optional[dict]:
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def clear_auth(path: str = DEFAULT_AUTH_FILE) -> None:
    if os.path.exists(path):
        try:
            os.remove(path)
        except OSError:
            pass


def is_token_expired(auth: dict, safety_margin: int = 300) -> bool:
    """True, если idToken истёк или истекает в ближайшие 5 минут."""
    if not auth:
        return True
    expires_at = auth.get("expiresAt", 0)
    return time.time() >= (expires_at - safety_margin)