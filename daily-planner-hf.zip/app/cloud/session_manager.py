# cloud/session_manager.py
"""
Управление пользовательской сессией Firebase Auth.

- Хранит токен в файле (auth_session.json).
- Автоматически обновляет idToken по refreshToken, когда срок почти истёк.
- Даёт одно место для login/logout/get_current_user.
"""
from typing import Optional
from cloud.firebase_auth import (
    sign_up, sign_in, refresh_id_token,
    FirebaseAuthError, auth_result_to_session,
)
from cloud.auth_storage import (
    save_auth, load_auth, clear_auth, is_token_expired,
    DEFAULT_AUTH_FILE,
)


class SessionManager:
    def __init__(self, auth_path: str = DEFAULT_AUTH_FILE):
        self.auth_path = auth_path
        self._auth: Optional[dict] = None
        self._load_from_disk()

    # ---------- Состояние ----------

    @property
    def is_authenticated(self) -> bool:
        return self._auth is not None and bool(self._auth.get("idToken"))

    @property
    def uid(self) -> Optional[str]:
        return self._auth.get("uid") if self._auth else None

    @property
    def email(self) -> Optional[str]:
        return self._auth.get("email") if self._auth else None

    @property
    def id_token(self) -> Optional[str]:
        return self._auth.get("idToken") if self._auth else None

    # ---------- Внутренние ----------

    def _load_from_disk(self):
        self._auth = load_auth(self.auth_path)

    def _persist(self):
        if self._auth:
            save_auth(self._auth, self.auth_path)
        else:
            clear_auth(self.auth_path)

    def ensure_fresh_token(self) -> str:
        """
        Возвращает актуальный idToken, обновляя его при необходимости.
        Бросает FirebaseAuthError, если refreshToken тоже протух.
        """
        if not self._auth:
            raise FirebaseAuthError("NO_SESSION", "Пользователь не авторизован")

        if not is_token_expired(self._auth):
            return self._auth["idToken"]

        # Обновляем
        refreshed = refresh_id_token(self._auth["refreshToken"])
        self._auth["idToken"] = refreshed["idToken"]
        self._auth["refreshToken"] = refreshed["refreshToken"]
        # Firebase выдаёт новый expiresIn
        import time
        self._auth["expiresAt"] = int(time.time()) + int(refreshed.get("expiresIn", 3600))
        self._persist()
        return self._auth["idToken"]

    # ---------- Публичный API ----------

    def login(self, email: str, password: str) -> dict:
        result = sign_in(email, password)
        self._auth = auth_result_to_session(result)
        self._persist()
        return self._auth

    def register(self, email: str, password: str) -> dict:
        result = sign_up(email, password)
        self._auth = auth_result_to_session(result)
        self._persist()
        return self._auth

    def logout(self):
        self._auth = None
        self._persist()