# views/tasks_view.py
"""Главный экран: список задач + фильтры в сетке + FAB + свайпы.

Фильтры сохраняются в SQLite (settings), чтобы не сбрасывались при перезапуске.
Дата фильтра передаётся в редактор, чтобы новая задача создавалась на этот день.
"""
import asyncio
from datetime import datetime, timedelta
import flet as ft
from ui.components import elevated_button, body_text, snack, divider
from ui.calendar_picker import show_task_date_picker
from views.period_filter_dialog import show_period_filter
from views.overdue_dialog import show_overdue_dialog
from db.local_db import CATEGORY_DEFAULT, CATEGORY_VALUES


CATEGORY_LABELS = {
    "personal": "Личные",
    "work": "Работа",
    "other": "Прочие",
}

SWIPE_VELOCITY_THRESHOLD = 300

SETTING_STATUS_FILTER = "ui_status_filter"
SETTING_CATEGORY_FILTER = "ui_category_filter"
SETTING_CONFIRM_CHECKBOX = "confirm_checkbox"   # "1" | "0"
SETTING_AUTHOR_LINE = "app_author_line"          # "Свобода выбора"


def _emoji_action(emoji, on_click, tooltip=None):
    return ft.Container(
        content=ft.Text(emoji, size=18),
        width=40, height=40,
        border_radius=20,
        alignment=ft.Alignment.CENTER,
        on_click=on_click,
        ink=True,
        tooltip=tooltip,
    )


def _emoji_nav(emoji, on_click, palette):
    return ft.Container(
        content=ft.Text(emoji, size=16),
        width=38, height=38,
        border_radius=19,
        bgcolor=palette["surface3"],
        alignment=ft.Alignment.CENTER,
        on_click=on_click,
        ink=True,
    )


def _filter_nav(on_click, palette):
    return ft.Container(
        content=ft.Icon(ft.Icons.FILTER_ALT, color=palette["accent"], size=20),
        width=42,
        height=42,
        border_radius=14,
        bgcolor=palette["surface3"],
        border=ft.Border.all(1, palette["accent"]),
        shadow=ft.BoxShadow(
            blur_radius=8,
            spread_radius=0,
            color=palette["accent"] + "55",
            offset=ft.Offset(0, 2),
        ),
        alignment=ft.Alignment.CENTER,
        on_click=on_click,
        ink=True,
        tooltip="Расширенный фильтр",
    )


def _urgency_color(task, palette):
    if task.get("status") == 1:
        return palette["text_muted"]
    dt = task.get("datetime")
    if not dt:
        return palette["text_muted"]
    try:
        task_dt = datetime.strptime(dt, "%Y-%m-%d %H:%M")
    except Exception:
        return palette["text_muted"]
    now = datetime.now()
    delta_min = (task_dt - now).total_seconds() / 60
    if delta_min < -10:
        return palette["danger"]
    if delta_min < 30:
        return palette["warning"]
    if delta_min < 180:
        return palette["accent"]
    return palette["success"]


def _show_details_dialog(page, palette, task, repo, on_close=None, font_scale=1.0):
    def _sz(n): return max(10, int(n * font_scale))
    """Диалог задачи: название, дата/время, примечание, детализация."""
    task_id = task["id"]
    details = list(task.get("details") or [])
    title = task.get("task") or "(без названия)"
    dt_str = task.get("datetime") or ""
    note = task.get("note") or ""

    def _sync_status():
        if not details:
            return
        all_done = all(d.get("done", False) for d in details)
        if all_done:
            repo.mark_task_complete(task_id, details=details)
        else:
            repo.update_task(task_id, status=0, details=details)

    def _fmt_dt(s):
        try:
            dt = datetime.strptime(s, "%Y-%m-%d %H:%M")
            return dt.strftime("%d.%m.%y %H:%M")
        except Exception:
            return s

    col = ft.Column(
        spacing=10,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
    )

    col.controls.append(
        ft.Text(title, color=palette["text"], size=17,
                weight=ft.FontWeight.W_600, selectable=True,
                max_lines=None),
    )

    if dt_str:
        col.controls.append(
            ft.Row(
                controls=[
                    ft.Text("🕐", size=13),
                    ft.Text(_fmt_dt(dt_str),
                            color=palette["text_muted"], size=13),
                ],
                spacing=6, tight=True,
            )
        )

    if note:
        col.controls.append(
            ft.Container(
                content=ft.Text(note, color=palette["text"], size=13,
                                selectable=True, max_lines=None),
                padding=ft.Padding.only(left=10, top=8, right=10, bottom=8),
                bgcolor=palette["surface2"],
                border_radius=8,
            )
        )

    # --- БЛОК БЫСТРОГО ПЕРЕНОСА ---
    def _postpone_task(new_dt):
        new_dt_str = new_dt.strftime("%Y-%m-%d %H:%M")
        # Запоминаем настройки напоминаний
        cfg = repo.get_reminder_config(task_id)
        
        # Обновляем время задачи
        repo.update_task(task_id, datetime=new_dt_str)
        
        # Пересоздаем напоминания (так как старое время прошло, нужно пересчитать)
        repo.set_reminders(task_id, 
                           before_min=cfg.get("before"), 
                           at_time=cfg.get("at_time"),
                           repeat=cfg.get("repeat"),
                           repeat_interval=cfg.get("repeat_interval", 5),
                           repeat_max=cfg.get("repeat_max", 4))
        
        page.pop_dialog()
        if on_close: on_close()

    def _do_postpone_hour(ev):
        try:
            dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M") + timedelta(hours=1)
            _postpone_task(dt)
        except Exception as ex:
            print(f"[postpone] hour error: {ex}")

    def _do_postpone_day(ev):
        try:
            dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M") + timedelta(days=1)
            _postpone_task(dt)
        except Exception as ex:
            print(f"[postpone] day error: {ex}")

    def _do_postpone_custom(ev):
        def date_picked(chosen_date):
            def time_picked(e_time):
                try:
                    t = e_time.control.value
                    t = t.time() if hasattr(t, "time") else t
                    combined_dt = datetime.combine(chosen_date, t)
                    _postpone_task(combined_dt)
                except Exception:
                    pass
            
            try:
                init_t = datetime.strptime(dt_str, "%Y-%m-%d %H:%M").time()
            except Exception:
                init_t = datetime.now().time()

            try:
                tp = ft.TimePicker(on_change=time_picked, value=init_t, hour_format=ft.TimePickerHourFormat.H24)
            except Exception:
                tp = ft.TimePicker(on_change=time_picked, value=init_t)
            page.overlay.append(tp)
            tp.open = True
            page.update()

        try:
            init_d = datetime.strptime(dt_str, "%Y-%m-%d").date()
        except Exception:
            init_d = datetime.now().date()
        
        show_task_date_picker(page=page, repo=repo, palette=palette, initial_date=init_d, on_select=date_picked)

    postpone_controls = ft.Column(
        controls=[
            ft.Container(height=10),
            ft.Text("Перенести задачу:", color=palette["text_muted"], size=12),
            ft.Container(height=6),
            ft.Row(
                controls=[
                    elevated_button("+1 час", _do_postpone_hour, palette, primary=False, expand=True, center_content=True, compact=True),
                    ft.Container(width=6),
                    elevated_button("+1 день", _do_postpone_day, palette, primary=False, expand=True, center_content=True, compact=True),
                    ft.Container(width=6),
                    elevated_button("Своё", _do_postpone_custom, palette, primary=False, expand=True, center_content=True, compact=True),
                ],
                spacing=0,
            ),
            ft.Container(height=10),
        ],
        spacing=0,
    )
    
    # Добавляем блок в самый низ перед детализацией или после неё
    col.controls.append(postpone_controls)
    # ------------------------------

    if details:
        col.controls.append(ft.Container(height=2))
        col.controls.append(
            ft.Text("Детализация", color=palette["text_muted"],
                    size=12, weight=ft.FontWeight.W_500)
        )
        for idx, d in enumerate(details):
            text = d.get("text", "")
            done = d.get("done", False)
            dur = d.get("duration", "") or ""
            prefix = f"⏱ {dur}  " if dur else ""

            checkbox_visual = ft.Container(
                content=ft.Icon(
                    ft.Icons.CHECK,
                    color="#FFFFFF" if done else "transparent",
                    size=14,
                ),
                width=24, height=24,
                bgcolor=palette["success"] if done else "transparent",
                border=None if done else ft.Border.all(2, palette["text_muted"]),
                border_radius=6,
                alignment=ft.Alignment.CENTER,
            )

            def make_toggle_row(i, visual):
                def toggle_row(ev):
                    details[i]["done"] = not details[i].get("done", False)
                    nd = details[i]["done"]
                    visual.content = ft.Icon(
                        ft.Icons.CHECK,
                        color="#FFFFFF" if nd else "transparent",
                        size=14,
                    )
                    visual.bgcolor = palette["success"] if nd else "transparent"
                    visual.border = (
                        None if nd else ft.Border.all(2, palette["text_muted"])
                    )
                    _sync_status()
                    try:
                        visual.update()
                    except Exception:
                        page.update()
                return toggle_row

            check_clickable = ft.Container(
                content=checkbox_visual,
                width=36, height=36,
                alignment=ft.Alignment.CENTER,
                on_click=make_toggle_row(idx, checkbox_visual),
            )

            text_label = ft.Text(
                prefix + text,
                color=palette["text"], size=14,
                max_lines=None,
                selectable=False,
            )

            row = ft.Row(
                controls=[
                    check_clickable,
                    ft.Container(width=6),
                    ft.Container(content=text_label, expand=True),
                ],
                spacing=0,
                vertical_alignment=ft.CrossAxisAlignment.START,
            )
            col.controls.append(row)

    def close(ev):
        page.pop_dialog()
        if on_close:
            on_close()

    dlg = ft.AlertDialog(
        modal=True,
        bgcolor=palette["surface"],
        inset_padding=ft.Padding.only(left=8, top=20, right=8, bottom=20),
        content_padding=ft.Padding.only(left=10, top=8, right=10, bottom=8),
        title=ft.Text("Задача", color=palette["text"], size=16),
        content=ft.Container(content=col, width=440, height=420),
        actions=[
            # Оборачиваем кнопку в Row, чтобы она красиво растянулась
            ft.Row(
                controls=[elevated_button("Закрыть", close, palette, primary=True, expand=True)],
                spacing=0,
            )
        ],
        actions_padding=ft.Padding.only(left=20, top=0, right=20, bottom=10),
    )
    page.show_dialog(dlg)

def _ask_copy(page, palette, task, on_confirm):
    task_id = task["id"]
    task_text = task.get("task", "")

    def yes(ev):
        page.pop_dialog()
        on_confirm(task_id)

    def no(ev):
        page.pop_dialog()

    copy_btn = elevated_button("Да", yes, palette,
                                primary=True, expand=True)
    cancel_btn = elevated_button("Отмена", no, palette, expand=True)

    dlg = ft.AlertDialog(
        modal=True,
        bgcolor=palette["surface"],
        title=ft.Text("Скопировать задачу?", color=palette["text"], size=16),
        content=ft.Text(
            f"Будет создана новая задача по образцу «{task_text}».",
            color=palette["text"], size=13,
        ),
        actions=[
            ft.Row(
                controls=[copy_btn, ft.Container(width=10), cancel_btn],
                spacing=0,
            ),
        ],
        actions_alignment=ft.MainAxisAlignment.CENTER,
    )
    page.show_dialog(dlg)


def _confirm_delete(page, palette, text, on_confirm):
    def do_it(ev):
        page.pop_dialog()
        on_confirm()

    def cancel(ev):
        page.pop_dialog()

    yes_btn = elevated_button("Да", do_it, palette, danger=True, expand=True)
    no_btn = elevated_button("Отмена", cancel, palette, expand=True)

    dlg = ft.AlertDialog(
        modal=True,
        bgcolor=palette["surface"],
        title=ft.Text("Подтверждение", color=palette["text"], size=16),
        content=ft.Text(text, color=palette["text"], size=13),
        actions=[
            ft.Row(
                controls=[yes_btn, ft.Container(width=10), no_btn],
                spacing=0,
            ),
        ],
        actions_alignment=ft.MainAxisAlignment.CENTER,
    )
    page.show_dialog(dlg)


def _confirm_toggle_status(page, palette, task, was_done, on_confirm):
    """Диалог подтверждения перед изменением статуса задачи."""
    task_text = task.get("task", "")
    if was_done:
        title = "Вернуть задачу в работу?"
        action_label = "Вернуть"
        action_danger = False
        body = f"Задача «{task_text}» снова станет активной."
    else:
        title = "Отметить как выполненное?"
        action_label = "Выполнено"
        action_danger = False
        body = f"Задача «{task_text}» будет отмечена выполненной."

    def do_it(ev):
        page.pop_dialog()
        on_confirm()

    def cancel(ev):
        page.pop_dialog()

    yes_btn = elevated_button(action_label, do_it, palette,
                              primary=True, danger=action_danger, expand=True)
    no_btn = elevated_button("Отмена", cancel, palette, expand=True)

    dlg = ft.AlertDialog(
        modal=True,
        bgcolor=palette["surface"],
        title=ft.Text(title, color=palette["text"], size=16),
        content=ft.Text(body, color=palette["text"], size=13),
        actions=[
            ft.Row(
                controls=[yes_btn, ft.Container(width=10), no_btn],
                spacing=0,
            ),
        ],
        actions_alignment=ft.MainAxisAlignment.CENTER,
    )
    page.show_dialog(dlg)

def _show_help_dialog(page, palette):
    """Справка по приложению. Открывается по тапу на заголовок «Ежедневник»."""

    def close(ev):
        page.pop_dialog()

    sections = [
        ("Основные действия", [
            "➕ — добавить задачу",
            "Короткий тап по задаче — подробности и подзадачи",
            "Долгий тап — скопировать задачу",
            "✏️ — редактировать",
            "🗑️ — удалить",
        ]),
        ("Верхняя панель", [
            "🔄 — синхронизация с облаком",
            "☀️ / 🌙 — сменить тему",
            "⚙️ — настройки",
        ]),
        ("Навигация и Календарь", [
            "Нажмите на дату по центру, чтобы открыть календарь",
            "В календаре над числами — счетчик задач (цвет = важность)",
            "Нажмите на месяц/год, чтобы быстро выбрать год",
            "📍 — вернуться к сегодня",
            "Свайп влево/вправо — листать дни",
        ]),
        ("Фильтры", [
            "Кнопки под датой: Все / Текущие / Выполн. и Категории",
            "Кнопка-воронка справа от даты — Расширенный фильтр",
            "В расширенном фильтре: период, типы задач, приоритеты",
            "Сброс расширенного фильтра — кнопка 📍 (Сегодня)",
        ]),
        ("Задачи и Повторы", [
            "Настройте повтор (ежедневно, ежемесячно и т.д.)",
            "Если задача просрочена, приложение спросит, как поступить",
            "Детализация: разбивайте задачу на шаги с таймером",
        ]),
        ("Напоминания", [
            "🔔 в карточке — есть активное напоминание",
            "В уведомлении: отложить на 5/10 мин или отключить",
            "Задача с напоминанием в прошлом — предложит исправить",
        ]),
        ("Настройки ⚙️", [
            "Разрешения: будильники, батарея, уведомления",
            "Поведение: подтверждение, автосинхронизация",
            "Категории: можно отключить, если не нужны",
            "Внешний вид: размер шрифта, значки в задачах",
            "Данные: очистка задач и напоминаний",
            "Аккаунт: смена пароля, выход",
        ]),
    ]

    col = ft.Column(
        spacing=0, 
        scroll=ft.ScrollMode.ALWAYS,
        height=400, 
        expand=True,
    )
    for title, items in sections:
        col.controls.append(
            ft.Text(title, color=palette["accent"], size=13,
                    weight=ft.FontWeight.W_600)
        )
        col.controls.append(ft.Container(height=4))
        for item in items:
            col.controls.append(
                ft.Text(item, color=palette["text"], size=12, max_lines=None)
            )
        col.controls.append(ft.Container(height=14))

    dlg = ft.AlertDialog(
        modal=True,
        bgcolor=palette["surface"],
        title=ft.Text("Справка", color=palette["text"], size=16),
        content=ft.Container(content=col, width=320, height=440),
        actions=[
            elevated_button("Закрыть", close, palette, primary=True)
        ],
        actions_padding=ft.Padding.only(left=20, top=0, right=20, bottom=10),
    )
    page.show_dialog(dlg)


def build_tasks_view(
    page: ft.Page,
    session,
    repo,
    palette: dict,
    sync_loop,
    on_logout,
    on_toggle_theme,
    on_edit_task=None,
    on_copy_task=None,
    on_settings=None,
    font_scale: float = 1.0,
):
    # ---------- Восстановление фильтров из SQLite ----------
    saved_status = repo.get_setting(SETTING_STATUS_FILTER, "current")
    if saved_status not in ("all", "current", "done"):
        saved_status = "current"

    saved_category = repo.get_setting(SETTING_CATEGORY_FILTER, "")
    categories_enabled = (repo.get_setting("categories_enabled", "1") or "1") == "1"
    if saved_category not in CATEGORY_VALUES or not categories_enabled:
        saved_category = None

    # Авторская строка в AppBar (можно менять из настроек)
    author_line = repo.get_setting(SETTING_AUTHOR_LINE, "Свобода выбора") or ""

    state = {
        "date": datetime.now().date(),
        "last_known_today": datetime.now().date(),
        "advanced_filter": None,
        "syncing": False,
        "status_filter": saved_status,
        "category_filter": saved_category,
        "categories_enabled": categories_enabled,
    }
    def _sz(base: int) -> int:
        return max(10, int(base * font_scale))

    def persist_filters():
        repo.set_setting(SETTING_STATUS_FILTER, state["status_filter"])
        repo.set_setting(SETTING_CATEGORY_FILTER, state["category_filter"] or "")

    def _confirm_checkbox_enabled() -> bool:
        return (repo.get_setting(SETTING_CONFIRM_CHECKBOX, "1") or "1") == "1"

    # ---------- Дата ----------
    date_label = ft.Text(
        "", color=palette["text"], size=20,
        weight=ft.FontWeight.W_700,
        max_lines=1, overflow=ft.TextOverflow.ELLIPSIS,
        text_align=ft.TextAlign.CENTER,
    )
    email_text = ft.Text(
        session.email or "", color=palette["text_muted"], size=11,
        max_lines=1, overflow=ft.TextOverflow.ELLIPSIS,
        text_align=ft.TextAlign.CENTER,
    )
    def update_date_label():
        advanced = state.get("advanced_filter")
        if advanced:
            start, end = advanced["start"], advanced["end"]
            date_label.value = f"{start:%d.%m.%y} – {end:%d.%m.%y}"
            return
        today = datetime.now().date()
        d = state["date"]
        if d == today:
            date_label.value = "Сегодня"
        elif d == today - timedelta(days=1):
            date_label.value = "Вчера"
        elif d == today + timedelta(days=1):
            date_label.value = "Завтра"
        else:
            date_label.value = d.strftime("%d.%m.%y")

    def go_prev(e=None):
        state["advanced_filter"] = None
        state["date"] -= timedelta(days=1)
        refresh_all()

    def go_next(e=None):
        state["advanced_filter"] = None
        state["date"] += timedelta(days=1)
        refresh_all()

    def go_today(e=None):
        state["date"] = datetime.now().date()
        state["advanced_filter"] = None
        refresh_all()

    # ---------- Список ----------
    tasks_list = ft.ListView(
        expand=True, spacing=0,
        padding=ft.Padding.only(left=6, top=6, right=6, bottom=20),
    )

    def get_filtered_tasks():
        date_str = state["date"].strftime("%Y-%m-%d")
        advanced = state.get("advanced_filter")
        if advanced:
            start, end = advanced["start"], advanced["end"]
            tasks = []
            for task in repo.get_all_tasks():
                try:
                    task_day = datetime.strptime(str(task.get("datetime", ""))[:10], "%Y-%m-%d").date()
                except Exception:
                    continue
                if start <= task_day <= end:
                    tasks.append(task)
            kind = advanced.get("kind", "all")
            if kind == "repeat":
                tasks = [t for t in tasks if isinstance(t.get("repeat"), dict)]
            elif kind == "one_time":
                tasks = [t for t in tasks if not isinstance(t.get("repeat"), dict)]
            elif kind == "hourly":
                tasks = [t for t in tasks if isinstance(t.get("repeat"), dict) and t["repeat"].get("type") == "hourly"]
            if advanced.get("high_priority"):
                tasks = [t for t in tasks if int(t.get("priority") or 0) >= 4]
            if advanced.get("hide_daily"):
                tasks = [t for t in tasks if not (isinstance(t.get("repeat"), dict) and t["repeat"].get("type") == "daily")]
        else:
            tasks = repo.get_tasks_for_day(date_str)
        sf = state["status_filter"]
        if sf == "current":
            tasks = [t for t in tasks if t["status"] == 0]
        elif sf == "done":
            tasks = [t for t in tasks if t["status"] == 1]
        cf = state["category_filter"]
        if state["categories_enabled"] and cf in CATEGORY_VALUES:
            tasks = [t for t in tasks if t.get("category") == cf]
        return tasks

    def task_card(task: dict, has_reminder: bool = False):
        # Читаем настройки видимости иконок
        try:
            vis_str = repo.get_setting("ui_visible_icons", "time,priority,note,repeat,subtasks,reminder") or ""
            visible_icons = set(vis_str.split(","))
        except Exception:
            visible_icons = {"time", "priority", "note", "repeat", "subtasks", "reminder"}

        task_id = task["id"]
        is_done = task["status"] == 1
        priority = max(1, min(5, task.get("priority", 3)))
        priority_color = palette["priority"][priority - 1]
        details = task.get("details") or []
        bar_color = _urgency_color(task, palette)

        def _do_toggle():
            repo.toggle_task_status(task_id)
            refresh_all()
            page.run_task(auto_sync_after_change)

        def on_checkbox_tap(e):
            if not _confirm_checkbox_enabled():
                _do_toggle()
                return
            _confirm_toggle_status(page, palette, task, is_done, _do_toggle)

        checkbox_visual = ft.Container(
            content=ft.Icon(ft.Icons.CHECK,
                            color="#FFFFFF" if is_done else "transparent",
                            size=20),
            width=34, height=34,
            bgcolor=palette["success"] if is_done else "transparent",
            border=None if is_done else ft.Border.all(2, palette["text_muted"]),
            border_radius=10,
            alignment=ft.Alignment.CENTER,
        )

        checkbox = ft.Container(
            content=checkbox_visual,
            width=48, height=48,
            alignment=ft.Alignment.CENTER,
            on_click=on_checkbox_tap,
        )

        if is_done:
            task_text = ft.Text(task["task"], color=palette["text_muted"], size=_sz(15),
                                style=ft.TextStyle(decoration=ft.TextDecoration.LINE_THROUGH),
                                max_lines=1, overflow=ft.TextOverflow.ELLIPSIS)
        else:
            task_text = ft.Text(task["task"], color=palette["text"], size=_sz(15),
                                weight=ft.FontWeight.W_500,
                                max_lines=1, overflow=ft.TextOverflow.ELLIPSIS)

        meta_items = []

        # 1. Время
        if "time" in visible_icons and task.get("datetime") and " " in task["datetime"]:
            time_part = task["datetime"].split(" ")[-1]
            if time_part:
                meta_items.append(ft.Row(
                    controls=[
                        ft.Text("🕐", size=12),
                        ft.Text(time_part, color=palette["text_muted"], size=12),
                    ],
                    spacing=2, tight=True,
                ))

        # 2. Приоритет
        if "priority" in visible_icons:
            meta_items.append(ft.Row(
                controls=[
                    ft.Text(str(priority), color=priority_color, size=12,
                            weight=ft.FontWeight.W_700),
                    ft.Text("★", color=priority_color, size=_sz(12)),
                ],
                spacing=1, tight=True,
            ))

        # 3. Примечание
        if "note" in visible_icons and task.get("note"):
            meta_items.append(ft.Text("📝", size=13))

        # 4. Повторение
        if "repeat" in visible_icons and task.get("repeat"):
            meta_items.append(ft.Text("🔁", size=13))

        # 5. Напоминание
        if "reminder" in visible_icons and has_reminder:
            meta_items.append(ft.Text("🔔", size=13))

        # 6. Подзадачи (детализация)
        if "subtasks" in visible_icons and details:
            total = len(details)
            done_cnt = sum(1 for d in details if d.get("done", False))
            meta_items.append(
                ft.Container(
                    content=ft.Row(
                        controls=[
                            ft.Text("📋", size=13),
                            ft.Text(f"{done_cnt}/{total}",
                                    color=palette["text_muted"], size=_sz(12)),
                        ],
                        spacing=3, tight=True,
                    ),
                    padding=ft.Padding.only(left=6, top=2, right=6, bottom=2),
                    border_radius=6,
                    bgcolor=palette["surface2"],
                )
            )
        # 7. Бейдж переноса
        if task.get("carried_over") == 1:
            meta_items.append(
                ft.Container(
                    content=ft.Text("⏩ Перенесена", color=palette["warning"], size=10, weight=ft.FontWeight.W_600),
                    padding=ft.Padding.only(left=6, top=2, right=6, bottom=2),
                    border_radius=6,
                    bgcolor=palette["warning"] + "22",
                )
            )

        meta_row = ft.Row(controls=meta_items, spacing=8, tight=True)

        def edit_task(e):
            if on_edit_task:
                on_edit_task(task_id,
                             task.get("category", CATEGORY_DEFAULT),
                             state["date"])

        edit_btn = ft.Container(
            content=ft.Text("✏️", size=16),
            width=40, height=40,
            border_radius=20,
            alignment=ft.Alignment.CENTER,
            on_click=edit_task,
            ink=True,
            tooltip="Редактировать",
        )

        def delete_task(e):
            def do_it():
                repo.delete_task(task_id)
                refresh_all()
                page.run_task(auto_sync_after_change)
            _confirm_delete(page, palette,
                            f"Удалить задачу «{task['task']}»?",
                            do_it)

        delete_btn = ft.Container(
            content=ft.Text("🗑️", size=16),
            width=40, height=40,
            border_radius=20,
            alignment=ft.Alignment.CENTER,
            on_click=delete_task,
            ink=True,
            tooltip="Удалить",
        )

        actions_row = ft.Row(
            controls=[edit_btn, delete_btn],
            spacing=0, tight=True,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

        left_bar = ft.Container(width=4, height=44, bgcolor=bar_color,
                                border_radius=2)

        text_col = ft.Column(
            controls=[task_text, meta_row],
            spacing=4, tight=True,
            alignment=ft.MainAxisAlignment.CENTER,
        )

        card_inner = ft.Container(
            content=ft.Row(
                controls=[
                    left_bar,
                    ft.Container(width=8),
                    checkbox,
                    ft.Container(width=2),
                    ft.Container(content=text_col, expand=True),
                    actions_row,
                ],
                spacing=0,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor=palette["surface"],
            border_radius=14,
            padding=ft.Padding.only(left=6, top=6, right=6, bottom=6),
            margin=ft.Margin.only(bottom=8),
            shadow=ft.BoxShadow(
                blur_radius=8, spread_radius=0,
                color=palette["shadow"] + palette["shadow_alpha"],
                offset=ft.Offset(0, 2),
            ),
        )

        def on_tap(e):
            _show_details_dialog(page, palette, task, repo, on_close=refresh_all, font_scale=font_scale)

        def on_long_press(e):
            def do_copy(tid):
                if on_copy_task:
                    state["date"] = datetime.now().date()
                    state["advanced_filter"] = None
                    refresh_all()
                    on_copy_task(tid,
                                 task.get("category", CATEGORY_DEFAULT),
                                 state["date"])
            _ask_copy(page, palette, task, do_copy)

        return ft.GestureDetector(
            content=card_inner,
            on_tap=on_tap,
            on_long_press=on_long_press,
        )

    def _empty_message():
        if state["status_filter"] == "done":
            return "Нет выполненных задач"
        if state["category_filter"] in CATEGORY_VALUES:
            label = CATEGORY_LABELS.get(state["category_filter"], "")
            return f"Нет задач в «{label}»"
        return "Нет задач за выбранный период" if state.get("advanced_filter") else "Нет задач на этот день"

    def build_list():
        tasks_list.controls.clear()
        tasks = get_filtered_tasks()
        
        if not tasks:
            tasks_list.controls.append(
                ft.Container(
                    content=ft.Column(
                        controls=[
                            ft.Text("📭", size=48),
                            ft.Container(height=12),
                            body_text(_empty_message(), palette, muted=True),
                            ft.Container(height=4),
                            body_text("Нажмите + чтобы добавить", palette,
                                      muted=True, size=12),
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=0,
                    ),
                    padding=60,
                    alignment=ft.Alignment.CENTER,
                )
            )
        else:
            try:
                task_ids_with_reminders = repo.get_task_ids_with_reminders()
            except Exception as ex:
                print(f"[tasks_view] get reminders error: {ex}")
                task_ids_with_reminders = set()

            # Если включен расширенный фильтр — рисуем разделители дат
            if state.get("advanced_filter"):
                last_date_str = None
                for t in tasks:
                    dt_str = t.get("datetime") or ""
                    date_str = dt_str[:10] if len(dt_str) >= 10 else ""
                    
                    if date_str and date_str != last_date_str:
                        try:
                            display_date = datetime.strptime(date_str, "%Y-%m-%d").strftime("%d.%m.%Y")
                        except Exception:
                            display_date = date_str
                        
                        tasks_list.controls.append(
                            ft.Container(
                                content=ft.Text(
                                    f"— Задачи за {display_date} —", 
                                    color=palette["text_muted"], 
                                    size=12, 
                                    weight=ft.FontWeight.W_500,
                                    text_align=ft.TextAlign.CENTER
                                ),
                                alignment=ft.Alignment.CENTER,
                                padding=ft.Padding.only(top=16, bottom=8),
                            )
                        )
                        last_date_str = date_str
                    
                    tasks_list.controls.append(
                        task_card(t, has_reminder=t["id"] in task_ids_with_reminders)
                    )
            else:
                # Обычный режим (без разделителей)
                for t in tasks:
                    tasks_list.controls.append(
                        task_card(t, has_reminder=t["id"] in task_ids_with_reminders)
                    )

    # ---------- Фильтры ----------
    status_chip_ctrls = {}
    category_chip_ctrls = {}

    def _apply_chip_visual(ctrl, is_active):
        is_light = palette.get("name") == "light"
        
        if is_active:
            if is_light:
                # Светлая тема, активная: темно-серый/серебристый
                ctrl.gradient = ft.LinearGradient(
                    begin=ft.Alignment.TOP_CENTER,
                    end=ft.Alignment.BOTTOM_CENTER,
                    colors=["#8E9AAF", "#5A6472"],
                )
                ctrl.border = ft.Border.all(1, "#FFFFFF")
                ctrl.shadow = ft.BoxShadow(blur_radius=4, color="#00000033", offset=ft.Offset(0, 2))
                ctrl.content.color = "#FFFFFF"
            else:
                # Темная тема, активная: синий глянец (как было)
                ctrl.gradient = ft.LinearGradient(
                    begin=ft.Alignment.TOP_CENTER,
                    end=ft.Alignment.BOTTOM_CENTER,
                    colors=["#4A6B8A", "#1C2D41"],
                )
                ctrl.border = ft.Border.all(2, "#FFFFFF")
                ctrl.shadow = ft.BoxShadow(blur_radius=8, spread_radius=0, color="#000000AA", offset=ft.Offset(0, 2))
                ctrl.content.color = "#FFFFFF"
        else:
            if is_light:
                # Светлая тема, неактивная: светло-серебристая
                ctrl.gradient = ft.LinearGradient(
                    begin=ft.Alignment.TOP_CENTER,
                    end=ft.Alignment.BOTTOM_CENTER,
                    colors=["#F2F4F7", "#D3D9E0"],
                )
                ctrl.border = ft.Border.all(1, "#B0B8C4")
                ctrl.shadow = ft.BoxShadow(blur_radius=2, color="#00000022", offset=ft.Offset(0, 1))
                ctrl.content.color = "#333333" # Темный текст для читаемости
            else:
                # Темная тема, неактивная (как было)
                ctrl.gradient = ft.LinearGradient(
                    begin=ft.Alignment.TOP_CENTER,
                    end=ft.Alignment.BOTTOM_CENTER,
                    colors=["#2D3340", "#1A1D24"],
                )
                ctrl.border = None
                ctrl.shadow = ft.BoxShadow(blur_radius=4, spread_radius=0, color="#000000AA", offset=ft.Offset(0, 2))
                ctrl.content.color = "#FFFFFF"

    def refresh_status_chips(update=True):
        for key, ctrl in status_chip_ctrls.items():
            _apply_chip_visual(ctrl, state["status_filter"] == key)
        if update:
            try:
                page.update()
            except Exception:
                pass

    def refresh_category_chips(update=True):
        cf = state["category_filter"]
        for key, ctrl in category_chip_ctrls.items():
            _apply_chip_visual(ctrl, cf == key)
        if update:
            try:
                page.update()
            except Exception:
                pass

    def set_status_filter(key):
        state["status_filter"] = key
        persist_filters()
        refresh_status_chips()
        build_list()
        try:
            page.update()
        except Exception:
            pass

    def set_category_filter(key):
        if state["category_filter"] == key:
            state["category_filter"] = None
        else:
            state["category_filter"] = key
        persist_filters()
        refresh_category_chips()
        build_list()
        try:
            page.update()
        except Exception:
            pass

    def make_chip(label, on_click, selected):
        text_ctrl = ft.Text(
            label,
            size=11,
            weight=ft.FontWeight.W_600,
            color="#FFFFFF",
            text_align=ft.TextAlign.CENTER,
            max_lines=1,
            no_wrap=True,
        )
        ctrl = ft.Container(
            content=text_ctrl,
            padding=ft.Padding.only(left=4, top=8, right=4, bottom=8),
            border_radius=16,
            on_click=on_click,
            ink=True,
            alignment=ft.Alignment.CENTER,
        )
        _apply_chip_visual(ctrl, selected)
        return ctrl

        if selected:
            # Активный: яркий градиент, белая обводка, свечение
            bg_colors = ["#4F8CFF", "#2E6BEA"]
            border = ft.Border.all(2, "#FFFFFF")
            shadow = ft.BoxShadow(
                blur_radius=8, spread_radius=0,
                color="#4F8CFF88",
                offset=ft.Offset(0, 2),
            )
        else:
            # Неактивный: тёмный градиент, без обводки
            bg_colors = ["#2D3340", "#1A1D24"]
            border = None
            shadow = ft.BoxShadow(
                blur_radius=4, spread_radius=0,
                color="#000000AA",
                offset=ft.Offset(0, 2),
            )

        return ft.Container(
            content=text_ctrl,
            padding=ft.Padding.only(left=4, top=8, right=4, bottom=8),
            border_radius=16,
            border=border,
            gradient=ft.LinearGradient(
                begin=ft.Alignment.TOP_CENTER,
                end=ft.Alignment.BOTTOM_CENTER,
                colors=bg_colors,
            ),
            shadow=shadow,
            on_click=on_click,
            ink=True,
            alignment=ft.Alignment.CENTER,
        )

    def _chip(label, key, is_status):
        if is_status:
            return make_chip(label,
                             on_click=lambda e, k=key: set_status_filter(k),
                             selected=(state["status_filter"] == key))
        return make_chip(label,
                         on_click=lambda e, k=key: set_category_filter(k),
                         selected=(state["category_filter"] == key))

    chip_all = _chip("Все", "all", True)
    chip_current = _chip("Текущие", "current", True)
    chip_done = _chip("Выполн.", "done", True)
    chip_personal = _chip("Личные", "personal", False)
    chip_work = _chip("Работа", "work", False)
    chip_other = _chip("Прочие", "other", False)

    status_chip_ctrls["all"] = chip_all
    status_chip_ctrls["current"] = chip_current
    status_chip_ctrls["done"] = chip_done
    category_chip_ctrls["personal"] = chip_personal
    category_chip_ctrls["work"] = chip_work
    category_chip_ctrls["other"] = chip_other

    # ---------- Свайпы ----------
    def on_swipe(e):
        try:
            v = e.primary_velocity or 0
        except Exception:
            v = 0
        if v > SWIPE_VELOCITY_THRESHOLD:
            go_prev()
        elif v < -SWIPE_VELOCITY_THRESHOLD:
            go_next()

    gesture_wrapper = ft.GestureDetector(
        content=ft.Container(content=tasks_list, expand=True),
        on_horizontal_drag_end=on_swipe,
        drag_interval=10,
        expand=True,
    )

    # ---------- Кнопка «+» ----------
    def open_add(e):
        if on_edit_task:
            state["date"] = datetime.now().date()
            state["advanced_filter"] = None
            refresh_all()
            cat = state["category_filter"] if state["categories_enabled"] else CATEGORY_DEFAULT
            if cat not in CATEGORY_VALUES:
                cat = CATEGORY_DEFAULT
            on_edit_task(None, cat, state["date"])

    add_btn = ft.Container(
        content=ft.Icon(ft.Icons.ADD, color="#FFFFFF", size=32),
        width=60, height=60,
        border_radius=30,
        border=ft.Border.all(2, "#FFFFFF"),
        gradient=ft.LinearGradient(
            begin=ft.Alignment.TOP_CENTER,
            end=ft.Alignment.BOTTOM_CENTER,
            colors=["#4A6B8A", "#1C2D41"],
        ),
        alignment=ft.Alignment.CENTER,
        on_click=open_add,
        ink=True,
        shadow=ft.BoxShadow(
            blur_radius=10, spread_radius=2,
            color="#000000AA",
            offset=ft.Offset(0, 5),
        ),
    )

    # ---------- Сетка фильтров ----------
    col1 = ft.Column(controls=[chip_all] + ([chip_personal] if state["categories_enabled"] else []), spacing=6, expand=True,
                     horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
    col2 = ft.Column(controls=[chip_current] + ([chip_work] if state["categories_enabled"] else []), spacing=6, expand=True,
                     horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
    col3 = ft.Column(controls=[chip_done] + ([chip_other] if state["categories_enabled"] else []), spacing=6, expand=True,
                     horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
    col4 = ft.Container(content=add_btn, alignment=ft.Alignment.CENTER, expand=True)

    filters_grid = ft.Row(
        controls=[col1, ft.Container(width=6), col2, ft.Container(width=6),
                  col3, ft.Container(width=6), col4],
        spacing=0,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )

    # ---------- Синхронизация ----------
    sync_btn_ref = {"icon_text": None, "container": None}

    async def auto_sync_after_change():
        try:
            await sync_loop.sync_now()
        except Exception:
            pass
        refresh_all()

    def _sync_set_busy(busy: bool):
        """Меняет иконку sync-кнопки и блокирует клики на время работы."""
        icon = sync_btn_ref.get("icon_text")
        cont = sync_btn_ref.get("container")
        if icon is None or cont is None:
            return
        try:
            icon.value = "⏳" if busy else "🔄"
            # во время синхронизации клик по кнопке отключён
            cont.on_click = None if busy else (
                lambda e: page.run_task(do_manual_sync, e)
            )
            page.update()
        except Exception:
            pass

    async def do_manual_sync(e=None):
        if state["syncing"]:
            return
        state["syncing"] = True
        _sync_set_busy(True)
        try:
            await sync_loop.sync_now_pull()
            await asyncio.sleep(0.6)
        finally:
            state["syncing"] = False
            _sync_set_busy(False)
            refresh_all()

    # ---------- AppBar ----------
    theme_emoji = "☀️" if palette["name"] == "dark" else "🌙"

    sync_icon_text = ft.Text("🔄", size=18)
    sync_btn = ft.Container(
        content=sync_icon_text,
        width=40, height=40,
        border_radius=20,
        alignment=ft.Alignment.CENTER,
        on_click=lambda e: page.run_task(do_manual_sync, e),
        ink=True,
        tooltip="Синхронизировать",
    )
    sync_btn_ref["icon_text"] = sync_icon_text
    sync_btn_ref["container"] = sync_btn

    theme_btn = _emoji_action(theme_emoji, on_click=on_toggle_theme,
                              tooltip="Сменить тему")

    def open_settings(e=None):
        asyncio.create_task(page.push_route("/settings"))
 

    settings_btn = _emoji_action("⚙️", on_click=open_settings, tooltip="Настройки")
#    logout_btn = _emoji_action("🚪", on_click=lambda e: on_logout(), tooltip="Выйти")

    # Заголовок AppBar: либо две строки (author + "Ежедневник"), либо одна.
    # Цвет надписи — как у основного текста (в тёмной теме светлый, в светлой тёмный).
    if author_line.strip():
        appbar_title = ft.Column(
            controls=[
                ft.Text("© " + author_line,
                        color=palette["text"],
                        size=11,
                        italic=True),
                ft.Text("Ежедневник",
                        color=palette["accent"],
                        size=20,
                        weight=ft.FontWeight.W_700),
            ],
            spacing=0,
            tight=True,
        )
    else:
        appbar_title = ft.Text("Ежедневник", color=palette["accent"],
                               size=20, weight=ft.FontWeight.W_700)

    appbar_title_clickable = ft.Container(
        content=appbar_title,
        on_click=lambda e: _show_help_dialog(page, palette),
        ink=False,
        padding=ft.Padding.only(left=2, top=2, right=2, bottom=2),
    )

    appbar = ft.AppBar(
        title=appbar_title_clickable,
        center_title=False,
        bgcolor=palette["surface"],
        color=palette["text"],
        actions=[sync_btn, theme_btn, settings_btn], # logout_btn],
    )

    # ---------- Строка даты ----------
    today_btn = _emoji_nav("📍", on_click=go_today, palette=palette)

    def pick_current_date(e=None):
        def date_picked(chosen_date):
            state["date"] = chosen_date
            state["advanced_filter"] = None
            refresh_all()

        show_task_date_picker(
            page=page,
            repo=repo,
            palette=palette,
            initial_date=state["date"],
            on_select=date_picked,
        )



    def open_period_filter(e=None):
        def apply_period(config):
            state["advanced_filter"] = config
            state["date"] = config["start"]
            refresh_all()

        show_period_filter(page, repo, palette, state.get("advanced_filter"), apply_period)

    period_filter_btn = _filter_nav(on_click=open_period_filter, palette=palette)



    date_row = ft.Container(
        content=ft.Row(
            controls=[
                today_btn,
                ft.Container(width=8),
                ft.Container(
                    content=ft.Column(
                        controls=[date_label, email_text],
                        spacing=0,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    expand=True,
                    alignment=ft.Alignment.CENTER,
                ),
                ft.Container(width=8),
                period_filter_btn,
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        padding=ft.Padding.only(left=8, top=6, right=8, bottom=6),
    )

    date_row.content.controls[2].on_click = pick_current_date
    date_row.content.controls[2].ink = True

    filters_block = ft.Container(
        content=filters_grid,
        padding=ft.Padding.only(left=10, top=4, right=10, bottom=8),
    )

    # ---------- Refresh ----------
    def refresh_all():
        # --- Проверка смены дня ---
        current_today = datetime.now().date()
        if current_today != state.get("last_known_today"):
            # Если пользователь смотрел на "сегодня", переключаем его на новое "сегодня"
            if state["date"] == state.get("last_known_today"):
                state["date"] = current_today
                state["advanced_filter"] = None
            state["last_known_today"] = current_today
        # ---------------------------
        
        update_date_label()
        refresh_status_chips()
        refresh_category_chips()
        build_list()
        try:
            date_label.update()
            tasks_list.update()
            page.update()
        except Exception:
            try:
                page.update()
            except Exception:
                pass
    def set_categories_enabled(enabled):
        state["categories_enabled"] = bool(enabled)
        if not state["categories_enabled"]:
            state["category_filter"] = None
            persist_filters()
        for column, status_chip, category_chip in (
            (col1, chip_all, chip_personal),
            (col2, chip_current, chip_work),
            (col3, chip_done, chip_other),
        ):
            column.controls.clear()
            column.controls.append(status_chip)
            if state["categories_enabled"]:
                column.controls.append(category_chip)
        refresh_category_chips(update=False)
        refresh_all()

    _overdue_state = {"running": False, "queue": []}

    def _process_overdue_queue():
        """Показывает следующий диалог из очереди или завершает."""
        if not _overdue_state["queue"]:
            _overdue_state["running"] = False
            return
        task = _overdue_state["queue"].pop(0)

        def _on_resolve(task_id, completed):
            try:
                repo.resolve_overdue_task(task_id, completed=completed)
            except Exception as ex:
                print(f"[overdue] resolve error: {ex}")
            # Автосинк после изменения
            try:
                page.run_task(auto_sync_after_change)
            except Exception:
                pass
            # Обновляем список и показываем следующий
            try:
                refresh_all()
            except Exception:
                pass
            # Небольшая пауза — даём UI перерисоваться
            async def _next():
                await asyncio.sleep(0.3)
                _process_overdue_queue()
            page.run_task(_next)

        show_overdue_dialog(page, palette, task, _on_resolve)

    def check_overdue():
        """Запускает проверку просроченных повторяющихся задач (только раз в сессию)."""
        if _overdue_state["running"]:
            return
        try:
            overdue = repo.get_overdue_recurring_tasks()
        except Exception as ex:
            print(f"[overdue] get_overdue error: {ex}")
            return
        if not overdue:
            return
        print(f"[overdue] {len(overdue)} overdue tasks to ask")
        _overdue_state["running"] = True
        _overdue_state["queue"] = list(overdue)
        _process_overdue_queue()

    # ---------- Сборка ----------
    update_date_label()
    refresh_status_chips()
    refresh_category_chips()
    build_list()

    view_divider = divider(palette)
    view = ft.View(
        route="/tasks",
        appbar=appbar,
        controls=[
            ft.Column(
                controls=[
                    date_row,
                    filters_block,
                    view_divider,
                    gesture_wrapper,
                ],
                spacing=0,
                expand=True,
            ),
        ],
        padding=0,
        bgcolor=palette["bg"],
    )

    def apply_palette(new_palette):
        nonlocal palette
        palette = new_palette

        view.bgcolor = palette["bg"]
        appbar.bgcolor = palette["surface"]
        appbar.color = palette["text"]
        date_label.color = palette["text"]
        email_text.color = palette["text_muted"]
        today_btn.bgcolor = palette["surface3"]
        period_filter_btn.bgcolor = palette["surface3"]
        period_filter_btn.border = ft.Border.all(1, palette["accent"])
        period_filter_btn.content.color = palette["accent"]
        period_filter_btn.shadow.color = palette["accent"] + "55"
        view_divider.bgcolor = palette["border"]
        add_btn.bgcolor = palette["accent"]
        add_btn.shadow.color = palette["accent"] + "88"
        theme_btn.content.value = "☀️" if palette["name"] == "dark" else "🌙"

        if author_line.strip():
            appbar_title.controls[0].color = palette["text"]
            appbar_title.controls[1].color = palette["accent"]
        else:
            appbar_title.color = palette["accent"]

        refresh_status_chips(update=False)
        refresh_category_chips(update=False)
        build_list()
        page.update()

    def open_task_details(task_id):
        try:
            task = repo.get_task(int(task_id))
        except (TypeError, ValueError):
            task = None
        if task:
            _show_details_dialog(
                page, palette, task, repo, on_close=refresh_all,
                font_scale=font_scale,
            )
        else:
            print(f"[notification] task not found locally: {task_id}")

    page._tasks_view_refs = {
        "refresh": refresh_all,
        "open_task_details": open_task_details,
        "set_categories_enabled": set_categories_enabled,
        "apply_palette": apply_palette,
        "check_overdue": check_overdue,
        "show": None,
        "hide": None,
    }
    return view