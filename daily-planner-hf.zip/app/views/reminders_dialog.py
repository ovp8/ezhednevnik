# views/reminders_dialog.py
"""Полноэкранный диалог настроек напоминаний (через overlay)."""
import flet as ft
from ui.components import styled_field, elevated_button


PRESETS = [
    ("5",    "За 5 мин"),
    ("15",   "За 15 мин"),
    ("30",   "За 30 мин"),
    ("60",   "За 1 час"),
    ("1440", "За 1 день"),
    ("custom", "Своё"),
]
PRESET_VALUES = {int(k) for k, _ in PRESETS if k != "custom"}


def _make_small_field(label, value, palette, width=64):
    f = styled_field(label, palette)
    f.value = str(value)
    f.keyboard_type = ft.KeyboardType.NUMBER
    f.width = width
    try:
        f.content_padding = ft.Padding.only(left=8, top=8, right=8, bottom=8)
    except Exception:
        pass
    return f


def make_toggle_row(label, value, on_change, palette):
    st = {"value": bool(value)}
    box_visual = ft.Container(
        content=ft.Icon(ft.Icons.CHECK, color="#FFFFFF" if st["value"] else "transparent", size=16),
        width=26, height=26,
        bgcolor=palette["accent"] if st["value"] else "transparent",
        border=None if st["value"] else ft.Border.all(2, palette["text_muted"]),
        border_radius=6,
        alignment=ft.Alignment.CENTER,
    )
    label_text = ft.Text(label, color=palette["text"], size=14, max_lines=None, expand=True)
    
    def toggle(e=None):
        st["value"] = not st["value"]
        box_visual.content = ft.Icon(ft.Icons.CHECK, color="#FFFFFF" if st["value"] else "transparent", size=16)
        box_visual.bgcolor = palette["accent"] if st["value"] else "transparent"
        box_visual.border = None if st["value"] else ft.Border.all(2, palette["text_muted"])
        try:
            box_visual.update()
        except Exception:
            pass
        on_change(st["value"])
        
    return ft.Container(
        content=ft.Row(controls=[box_visual, ft.Container(width=12), label_text], vertical_alignment=ft.CrossAxisAlignment.CENTER),
        padding=ft.Padding.only(left=4, top=10, right=4, bottom=10),
        on_click=toggle,
        ink=True,
    )


def open_reminders_dialog(page, palette, cfg, on_save, on_close=None):
    st = {
        "before_enabled": cfg.get("before") is not None,
        "before_value": "15",
        "before_d": 0, "before_h": 0, "before_m": 15,
        "at_time": bool(cfg.get("at_time")),
        "repeat": bool(cfg.get("repeat")),
        "repeat_interval": int(cfg.get("repeat_interval") or 5),
        "repeat_max": int(cfg.get("repeat_max") or 4),
    }
    if st["before_enabled"]:
        bv = int(cfg.get("before") or 0)
        if bv in PRESET_VALUES:
            st["before_value"] = str(bv)
        else:
            st["before_value"] = "custom"
            st["before_d"] = bv // 1440
            st["before_h"] = (bv % 1440) // 60
            st["before_m"] = bv % 60

    presets_holder = ft.Container()
    custom_holder = ft.Container(visible=(st["before_value"] == "custom"))
    repeat_holder = ft.Container(visible=st["repeat"])

    # ---------- Раздел 1: заранее ----------
    def build_preset_chips():
        row = ft.Row(spacing=6, wrap=True)
        for key, label in PRESETS:
            selected = (st["before_value"] == key)
            
            chip = ft.Container(
                content=ft.Text(label, size=12, weight=ft.FontWeight.W_500,
                                color="#FFFFFF" if selected else palette["text"]),
                padding=ft.Padding.only(left=10, top=8, right=10, bottom=8),
                border_radius=16,
                on_click=lambda e, k=key: set_preset(k),
                ink=True,
                animate=ft.Animation(150, ft.AnimationCurve.EASE_OUT),
            )
            
            if selected:
                chip.gradient = ft.LinearGradient(
                    begin=ft.Alignment.TOP_CENTER,
                    end=ft.Alignment.BOTTOM_CENTER,
                    colors=["#4A6B8A", "#1C2D41"],
                )
                chip.border = ft.Border.all(1, "#FFFFFF")
                chip.bgcolor = None
            else:
                chip.gradient = None
                chip.bgcolor = palette["surface2"]
                chip.border = None
                
            row.controls.append(chip)
        return row

    def set_preset(key):
        st["before_value"] = key
        custom_holder.visible = (key == "custom")
        presets_holder.content = build_preset_chips()
        try:
            presets_holder.update()
            custom_holder.update()
        except Exception:
            page.update()

    presets_holder.content = build_preset_chips()

    f_d = _make_small_field("Дней", st["before_d"], palette)
    f_h = _make_small_field("Часов", st["before_h"], palette)
    f_m = _make_small_field("Минут", st["before_m"], palette)

    def on_custom_change(e):
        try: st["before_d"] = max(0, int((f_d.value or "0").strip() or "0"))
        except Exception: st["before_d"] = 0
        try: st["before_h"] = max(0, int((f_h.value or "0").strip() or "0"))
        except Exception: st["before_h"] = 0
        try: st["before_m"] = max(0, int((f_m.value or "0").strip() or "0"))
        except Exception: st["before_m"] = 0

    f_d.on_change = on_custom_change
    f_h.on_change = on_custom_change
    f_m.on_change = on_custom_change

    custom_holder.content = ft.Row(
        controls=[
            ft.Container(content=f_d, expand=True),
            ft.Container(width=6),
            ft.Container(content=f_h, expand=True),
            ft.Container(width=6),
            ft.Container(content=f_m, expand=True),
        ],
        spacing=0,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )

    # ---------- Чекбоксы ----------
    before_check = make_toggle_row(
        "Предупредить заранее", 
        st["before_enabled"], 
        lambda v: st.update({"before_enabled": v}), 
        palette
    )

    at_time_check = make_toggle_row(
        "Напомнить в момент события", 
        st["at_time"], 
        lambda v: st.update({"at_time": v}), 
        palette
    )

    def on_repeat_toggle_visual(val):
        st["repeat"] = val
        repeat_holder.visible = val
        try:
            repeat_holder.update()
        except Exception:
            page.update()

    repeat_check = make_toggle_row(
        "Повторять, если не выполнено", 
        st["repeat"], 
        on_repeat_toggle_visual, 
        palette
    )

    # ---------- Поля для повтора ----------
    f_interval = _make_small_field("Каждые, мин", st["repeat_interval"], palette, width=90)
    f_max = _make_small_field("Не больше, раз", st["repeat_max"], palette, width=90)

    def on_repeat_change(e):
        try: st["repeat_interval"] = max(1, int((f_interval.value or "5").strip() or "5"))
        except Exception: st["repeat_interval"] = 5
        try: st["repeat_max"] = max(1, int((f_max.value or "4").strip() or "4"))
        except Exception: st["repeat_max"] = 4

    f_interval.on_change = on_repeat_change
    f_max.on_change = on_repeat_change

    repeat_holder.content = ft.Row(
        controls=[
            ft.Container(content=f_interval, expand=True),
            ft.Container(width=8),
            ft.Container(content=f_max, expand=True),
        ],
        spacing=0,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )

    # ---------- Контент ----------
    content_col = ft.Column(
        controls=[
            ft.Container(height=4),
            before_check,
            ft.Container(height=8),
            presets_holder,
            ft.Container(height=8),
            custom_holder,
            ft.Container(height=20),
            ft.Container(height=1, bgcolor=palette["border"]),
            ft.Container(height=12),
            at_time_check,
            ft.Container(height=20),
            ft.Container(height=1, bgcolor=palette["border"]),
            ft.Container(height=12),
            repeat_check,
            ft.Container(height=8),
            repeat_holder,
            ft.Container(height=30),
        ],
        spacing=0,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
    )

    # ---------- Overlay refs ----------
    _refs = {"backdrop": None, "card": None}

    def _do_close():
        for key in ("card", "backdrop"):
            ctrl = _refs.get(key)
            if ctrl is not None:
                try:
                    page.overlay.remove(ctrl)
                except Exception:
                    pass
        try:
            page.update()
        except Exception:
            pass

        if on_close:
            try:
                on_close()
            except Exception:
                pass

    def _do_clear():
        result = {"before": None, "at_time": False, "repeat": False,
                  "repeat_interval": 5, "repeat_max": 4}
        _do_close()
        try:
            on_save(result)
        except Exception as ex:
            print(f"[reminders_dialog] on_save error: {ex}")

    def _do_commit():
        before_val = None
        if st["before_enabled"]:
            if st["before_value"] == "custom":
                before_val = st["before_d"] * 1440 + st["before_h"] * 60 + st["before_m"]
                if before_val <= 0:
                    before_val = 15
            else:
                before_val = int(st["before_value"])

        result = {
            "before": before_val,
            "at_time": bool(st["at_time"]),
            "repeat": bool(st["repeat"]),
            "repeat_interval": int(st["repeat_interval"]),
            "repeat_max": int(st["repeat_max"]),
        }
        if result["repeat"] and result["before"] is None and not result["at_time"]:
            result["at_time"] = True
        if result["before"] is None and not result["at_time"]:
            result["repeat"] = False

        _do_close()
        try:
            on_save(result)
        except Exception as ex:
            print(f"[reminders_dialog] on_save error: {ex}")

    # ---------- UI ----------
    header = ft.Container(
        content=ft.Row(
            controls=[
                ft.IconButton(icon=ft.Icons.ARROW_BACK,
                              icon_color=palette["text"],
                              on_click=lambda e: _do_close()),
                ft.Text("Напоминания", color=palette["text"],
                        size=18, weight=ft.FontWeight.W_600, expand=True),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        padding=ft.Padding.only(left=4, top=4, right=4, bottom=4),
        bgcolor=palette["surface"],
    )

    # ---------- Футер (только один, без дублей) ----------
    clear_btn = elevated_button(
        "Отключить", lambda e: _do_clear(), palette, 
        primary=False, expand=True
    )
    
    save_btn = elevated_button(
        "Готово", lambda e: _do_commit(), palette, 
        primary=True, expand=True
    )

    footer = ft.Container(
        content=ft.Row(
            controls=[
                clear_btn, 
                ft.Container(width=10), 
                save_btn
            ],
            spacing=0,
        ),
        padding=ft.Padding.only(left=16, top=10, right=16, bottom=20),
        bgcolor=palette["surface"],
    )

    body = ft.Container(
        content=content_col,
        padding=ft.Padding.only(left=16, top=10, right=16, bottom=10),
        expand=True,
    )

    root = ft.Column(
        controls=[
            header,
            ft.Container(height=1, bgcolor=palette["border"]),
            body,
            footer,
        ],
        spacing=0,
        expand=True,
    )

    # ---------- Оверлей ----------
    backdrop = ft.Container(
        bgcolor="#99000000",
        left=0, top=0, right=0, bottom=0,
        on_click=lambda e: _do_close(),
    )
    _refs["backdrop"] = backdrop

    dialog_card = ft.Container(
        content=root,
        left=6, top=40, right=6, bottom=70, # <-- top=40
        bgcolor=palette["bg"],
        border_radius=12,
    )
    _refs["card"] = dialog_card

    page.overlay.append(backdrop)
    page.overlay.append(dialog_card)
    page.update()