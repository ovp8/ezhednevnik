# views/login_view.py
"""Экран входа / регистрации."""
import flet as ft
from ui.components import (
    elevated_button, title_text, body_text, styled_field, snack, emoji_button
)


FIELD_WIDTH = 320   # ширина полей ввода
BUTTON_WIDTH = 320  # ширина кнопки


def build_login_view(page, session, palette, on_success, on_toggle_theme):
    email_field = styled_field("Email", palette, keyboard_type=ft.KeyboardType.EMAIL)
    email_field.width = FIELD_WIDTH

    password_field = styled_field("Пароль", palette, password=True)
    password_field.width = FIELD_WIDTH

    error_text = ft.Text("", color=palette["danger"], size=13)
    success_text = ft.Text("", color=palette["success"], size=13)

    is_register_mode = {"value": False}
    mode_title = title_text("Вход", palette, size=26)
    app_title = title_text("Ежедневник", palette, size=30)
    submit_btn_holder = ft.Container()

    def do_submit(e):
        email = (email_field.value or "").strip()
        password = password_field.value or ""
        error_text.value = ""
        success_text.value = ""
        page.update()

        if not email or not password:
            error_text.value = "Заполните email и пароль"
            page.update()
            return
        if len(password) < 6:
            error_text.value = "Пароль не короче 6 символов"
            page.update()
            return
        try:
            if is_register_mode["value"]:
                session.register(email, password)
                snack(page, "Регистрация успешна", palette)
            else:
                session.login(email, password)
                snack(page, "Вход выполнен", palette)
            on_success()
        except Exception as ex:
            if hasattr(ex, "message"):
                error_text.value = ex.message
            else:
                error_text.value = str(ex)
            page.update()

    def do_forgot(e):
        email = (email_field.value or "").strip()
        error_text.value = ""
        success_text.value = ""
        if not email:
            error_text.value = "Введите email, чтобы сбросить пароль"
            page.update()
            return
        try:
            from cloud.firebase_auth import send_password_reset
            send_password_reset(email)
            success_text.value = f"Письмо отправлено на {email}"
            page.update()
        except Exception as ex:
            if hasattr(ex, "message"):
                error_text.value = ex.message
            else:
                error_text.value = str(ex)
            page.update()

    def rebuild_submit(update=True):
        label = "Зарегистрироваться" if is_register_mode["value"] else "Войти"
        btn = elevated_button(label, do_submit, palette, primary=True)
        btn.width = BUTTON_WIDTH
        submit_btn_holder.content = btn
        if update:
            page.update()

    def toggle_mode(e):
        is_register_mode["value"] = not is_register_mode["value"]
        mode_title.value = "Регистрация" if is_register_mode["value"] else "Вход"
        error_text.value = ""
        success_text.value = ""
        rebuild_submit()

    toggle_text = ft.Text("Вход  / Зарегистрироваться",
                          color=palette["accent"], size=13)
    toggle_holder = ft.Container(content=toggle_text, on_click=toggle_mode, padding=8)

    forgot_text = ft.Text("Забыли пароль?", color=palette["text_muted"], size=12)
    forgot_holder = ft.Container(content=forgot_text, on_click=do_forgot, padding=8)

    theme_btn = emoji_button(
        "☀️" if palette["name"] == "dark" else "🌙",
        on_toggle_theme, palette, size=42,
    )

    header = ft.Row(
        controls=[ft.Container(expand=True), theme_btn],
    )

    # ЦЕНТРАЛЬНЫЙ БЛОК — БЕЗ подзаголовка
    content = ft.Column(
        controls=[
            header,
            ft.Container(height=20),
            ft.Row([ft.Text("🗓️", size=56)], alignment=ft.MainAxisAlignment.CENTER),
            ft.Container(height=10),
            ft.Row([app_title], alignment=ft.MainAxisAlignment.CENTER),
            ft.Container(height=36),
            ft.Row([mode_title], alignment=ft.MainAxisAlignment.CENTER),
            ft.Container(height=24),
            ft.Row([email_field], alignment=ft.MainAxisAlignment.CENTER),
            ft.Container(height=12),
            ft.Row([password_field], alignment=ft.MainAxisAlignment.CENTER),
            ft.Container(height=8),
            ft.Row(
                [ft.Container(content=error_text, width=FIELD_WIDTH)],
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            ft.Row(
                [ft.Container(content=success_text, width=FIELD_WIDTH)],
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            ft.Container(height=16),
            ft.Row([submit_btn_holder], alignment=ft.MainAxisAlignment.CENTER),
            ft.Container(height=6),
            ft.Row([toggle_holder], alignment=ft.MainAxisAlignment.CENTER),
            ft.Row([forgot_holder], alignment=ft.MainAxisAlignment.CENTER),
        ],
        spacing=0,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )

    # ListView вместо Column — решает overflow при клавиатуре
    outer = ft.Container(
        content=ft.ListView(
            controls=[content],
            spacing=0,
            padding=0,
            auto_scroll=False,
        ),
        padding=20,
        expand=True,
        bgcolor=palette["bg"],
    )

    def apply_palette(new_palette):
        nonlocal palette
        palette = new_palette
        outer.bgcolor = palette["bg"]
        error_text.color = palette["danger"]
        success_text.color = palette["success"]
        mode_title.color = palette["text"]
        app_title.color = palette["text"]
        toggle_text.color = palette["accent"]
        forgot_text.color = palette["text_muted"]

        for field in (email_field, password_field):
            field.bgcolor = palette["surface2"]
            field.color = palette["text"]
            field.border_color = palette["border"]
            field.focused_border_color = palette["accent"]
            field.cursor_color = palette["accent"]
            field.label_style = ft.TextStyle(color=palette["text_muted"], size=13)

        theme_btn.bgcolor = palette["surface3"]
        theme_btn.content.color = palette["text"]
        theme_btn.content.value = "☀️" if palette["name"] == "dark" else "🌙"
        rebuild_submit(update=False)
        page.update()

    page._login_view_refs = {"apply_palette": apply_palette}
    rebuild_submit()
    return outer
