# views/cleanup_view.py
"""Overlay экран очистки данных.

Фильтры:
  • Дата «до» — по умолчанию сегодня
  • Категории — toggle-чипсы Личные/Работа/Прочие (пусто = все)

Действия (4):
  • Удалить выполненные (status=1)
  • Удалить все задачи
  • Сбросить все уведомления (pending)
  • Очистить отработанные напоминания (fired)
"""
import flet as ft
from datetime import datetime, timezone


def _get_date_from_picker(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone().date()
    if hasattr(value, "year"):
        return value
    return None


def open_cleanup_overlay(page, palette, repo, on_done=None):
    """Открывает overlay очистки."""

    reminder_storage = getattr(repo, "reminders", None)

    state = {
        "date": datetime.now().date(),
        "categories": set(),   # пусто = все
    }

    overlay_refs = {"backdrop": None, "card": None}

    def _close():
        for key in ("card", "backdrop"):
            ctrl = overlay_refs.get(key)
            if ctrl is not None:
                try:
                    page.overlay.remove(ctrl)
                except Exception:
                    pass
        try:
            page.update()
        except Exception:
            pass
        if on_done:
            try:
                on_done()
            except Exception:
                pass

    # ---- UI helpers ----
    def section_title(text):
        return ft.Container(
            content=ft.Text(text, color=palette["text_muted"], size=12,
                            weight=ft.FontWeight.W_500),
            padding=ft.Padding.only(left=4, top=14, bottom=6),
        )

    # ---- Дата «до» ----
    date_label = ft.Text("", color=palette["text"], size=14, weight=ft.FontWeight.W_500)

    def update_date_label():
        date_label.value = state["date"].strftime("%d.%m.%Y")

    date_field_holder = ft.Container()

    def pick_date(e=None):
        def picked(ev):
            d = _get_date_from_picker(ev.control.value)
            if d:
                state["date"] = d
                update_date_label()
                try:
                    date_label.update()
                except Exception:
                    page.update()

        try:
            init = datetime.combine(state["date"], datetime.min.time())
        except Exception:
            init = datetime.now()
        dp = ft.DatePicker(on_change=picked, value=init)
        try:
            dp.locale = ft.Locale("ru")
        except Exception:
            pass
        page.overlay.append(dp)
        dp.open = True
        page.update()

    date_field_holder.content = ft.Container(
        content=ft.Row(
            controls=[
                ft.Icon(ft.Icons.CALENDAR_MONTH, size=20,
                        color=palette["text_muted"]),
                ft.Container(width=10),
                date_label,
                ft.Container(expand=True),
                ft.Icon(ft.Icons.ARROW_DROP_DOWN, size=18,
                        color=palette["text_muted"]),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        padding=ft.Padding.only(left=14, top=12, right=14, bottom=12),
        bgcolor=palette["surface2"],
        border_radius=12,
        on_click=pick_date,
        ink=True,
    )

    # ---- Категории-чипсы ----
    CATEGORY_LABELS = {"personal": "Личные", "work": "Работа", "other": "Прочие"}
    chips_row = ft.Row(spacing=6, wrap=True)

    def build_chips():
        chips_row.controls.clear()
        for key, label in CATEGORY_LABELS.items():
            selected = key in state["categories"]
            chips_row.controls.append(
                ft.Container(
                    content=ft.Text(
                        label, size=13,
                        weight=ft.FontWeight.W_500,
                        color="#FFFFFF" if selected else palette["text"],
                    ),
                    padding=ft.Padding.only(left=14, top=8, right=14, bottom=8),
                    border_radius=16,
                    bgcolor=palette["accent"] if selected else palette["surface2"],
                    on_click=lambda e, k=key: toggle_cat(k),
                    ink=True,
                )
            )

    def toggle_cat(key):
        if key in state["categories"]:
            state["categories"].discard(key)
        else:
            state["categories"].add(key)
        build_chips()
        try:
            chips_row.update()
        except Exception:
            page.update()

    build_chips()

    # ---- Подтверждение ----
    def confirm(title, body, on_yes, danger=True):
        def do_yes(ev):
            page.pop_dialog()
            on_yes()

        def do_no(ev):
            page.pop_dialog()

        yes_color = "#FFFFFF"
        yes_bg = palette["danger"] if danger else palette["accent"]

        dlg = ft.AlertDialog(
            modal=True,
            bgcolor=palette["surface"],
            title=ft.Text(title, color=palette["text"], size=16),
            content=ft.Text(body, color=palette["text"], size=13),
            actions=[
                ft.Row(
                    controls=[
                        ft.Container(
                            content=ft.Text("Да", color=yes_color, size=14,
                                            weight=ft.FontWeight.W_600),
                            padding=ft.Padding.only(left=16, top=10, right=16, bottom=10),
                            bgcolor=yes_bg, border_radius=12,
                            on_click=do_yes, ink=True, expand=True,
                            alignment=ft.Alignment.CENTER,
                        ),
                        ft.Container(width=10),
                        ft.Container(
                            content=ft.Text("Отмена", color=palette["text"],
                                            size=14, weight=ft.FontWeight.W_600),
                            padding=ft.Padding.only(left=16, top=10, right=16, bottom=10),
                            bgcolor=palette["surface2"], border_radius=12,
                            on_click=do_no, ink=True, expand=True,
                            alignment=ft.Alignment.CENTER,
                        ),
                    ],
                    spacing=0,
                ),
            ],
            actions_alignment=ft.MainAxisAlignment.CENTER,
        )
        page.show_dialog(dlg)

    # ---- Действия ----
    def do_delete_done(e=None):
        cats = list(state["categories"]) or [None]
        total = 0
        date_str = state["date"].strftime("%Y-%m-%d")
        try:
            for cat in cats:
                total += repo.db.delete_tasks_before(
                    date_str, user_id=repo._uid, category=cat, only_done=True
                )
        except Exception as ex:
            print(f"[cleanup] delete done error: {ex}")
            return
        _show_snack(f"Удалено выполненных: {total}")
        if on_done:
            try:
                on_done()
            except Exception:
                pass

    def do_delete_all(e=None):
        cats = list(state["categories"]) or [None]
        total = 0
        date_str = state["date"].strftime("%Y-%m-%d")
        try:
            for cat in cats:
                total += repo.db.delete_tasks_before(
                    date_str, user_id=repo._uid, category=cat, only_done=False
                )
        except Exception as ex:
            print(f"[cleanup] delete all error: {ex}")
            return
        _show_snack(f"Удалено задач: {total}")
        if on_done:
            try:
                on_done()
            except Exception:
                pass

    def do_clear_pending(e=None):
        if not reminder_storage:
            _show_snack("Напоминания недоступны")
            return
        try:
            n = reminder_storage.clear_pending()
        except Exception as ex:
            print(f"[cleanup] clear pending error: {ex}")
            return
        _show_snack(f"Сброшено напоминаний: {n}")

    def do_clear_fired(e=None):
        if not reminder_storage:
            _show_snack("Напоминания недоступны")
            return
        date_str = state["date"].strftime("%Y-%m-%dT00:00:00.000Z")
        try:
            n = reminder_storage.clear_fired_before(date_str)
        except Exception as ex:
            print(f"[cleanup] clear fired error: {ex}")
            return
        _show_snack(f"Очищено отработанных: {n}")

    def _show_snack(text):
        page.snack_bar = ft.SnackBar(
            content=ft.Text(text, color="#FFFFFF"),
            bgcolor=palette["success"],
            duration=2500,
        )
        page.snack_bar.open = True
        page.update()

    # ---- Карточка действия ----
    def action_card(label, subtitle, on_click, danger=True):
        color = palette["danger"] if danger else palette["accent"]
        return ft.Container(
            content=ft.Row(
                controls=[
                    ft.Icon(ft.Icons.DELETE_OUTLINE if danger else ft.Icons.RESTORE,
                            size=20, color=color),
                    ft.Container(width=10),
                    ft.Column(
                        controls=[
                            ft.Text(label, color=palette["text"], size=14,
                                    weight=ft.FontWeight.W_500),
                            ft.Text(subtitle, color=palette["text_muted"],
                                    size=11, max_lines=2),
                        ],
                        spacing=2,
                        expand=True,
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.only(left=12, top=12, right=12, bottom=12),
            bgcolor=palette["surface2"],
            border_radius=12,
            on_click=on_click,
            ink=True,
            margin=ft.Margin.only(bottom=8),
        )

    # ============================================================
    #  Контент
    # ============================================================
    update_date_label()

    content = ft.Column(
        controls=[
            section_title("Фильтр — до какой даты"),
            date_field_holder,

            section_title("Категории (пусто = все)"),
            chips_row,

            section_title("Действия"),
            action_card(
                "Удалить выполненные",
                "Все задачи со статусом «выполнено» до указанной даты",
                lambda e: confirm(
                    "Удалить выполненные?",
                    "Действие необратимо. Синхронизация удалит их и в облаке.",
                    do_delete_done,
                ),
            ),
            action_card(
                "Удалить все задачи",
                "Все задачи (выполненные и активные) до указанной даты",
                lambda e: confirm(
                    "Удалить все задачи?",
                    "Будут удалены ВСЕ задачи до указанной даты. Действие необратимо.",
                    do_delete_all,
                ),
            ),
            action_card(
                "Сбросить все уведомления",
                "Убирает все несработавшие напоминания (задачи не трогает)",
                lambda e: confirm(
                    "Сбросить уведомления?",
                    "Все запланированные напоминания будут удалены.",
                    do_clear_pending,
                    danger=False,
                ),
                danger=False,
            ),
            action_card(
                "Очистить отработанные напоминания",
                "Удаляет сработавшие напоминания до указанной даты",
                lambda e: confirm(
                    "Очистить отработанные?",
                    "Удаляются записи о уже сработавших напоминаниях.",
                    do_clear_fired,
                    danger=False,
                ),
                danger=False,
            ),

            ft.Container(height=30),
        ],
        spacing=0,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
    )

    # ---- Header + корень ----
    header = ft.Container(
        content=ft.Row(
            controls=[
                ft.IconButton(
                    icon=ft.Icons.ARROW_BACK,
                    icon_color=palette["text"],
                    on_click=lambda e: _close(),
                ),
                ft.Text("Очистка данных", color=palette["text"],
                        size=18, weight=ft.FontWeight.W_600, expand=True),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        padding=ft.Padding.only(left=4, top=4, right=4, bottom=4),
        bgcolor=palette["surface"],
    )

    body = ft.Container(
        content=content,
        padding=ft.Padding.only(left=16, top=10, right=16, bottom=20),
        expand=True,
    )

    root = ft.Column(
        controls=[
            header,
            ft.Container(height=1, bgcolor=palette["border"]),
            body,
        ],
        spacing=0,
        expand=True,
    )

    # ---- Overlay ----
    backdrop = ft.Container(
        bgcolor="#99000000",
        left=0, top=0, right=0, bottom=0,
        on_click=lambda e: _close(),
    )
    overlay_refs["backdrop"] = backdrop

    dialog_card = ft.Container(
        content=root,
        left=6, top=6, right=6, bottom=6,
        bgcolor=palette["bg"],
        border_radius=12,
    )
    overlay_refs["card"] = dialog_card

    page.overlay.append(backdrop)
    page.overlay.append(dialog_card)
    page.update()